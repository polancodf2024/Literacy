"""
generar_datos_sinteticos.py
============================
Genera un dataset sintético LARGO con las cuatro trayectorias prototípicas
descritas en el manuscrito (Sección 7.5):

  - Mejorando:   aciertos aumentan de ~2 a ~9 a lo largo de las semanas
  - Estancado:   aciertos permanecen en torno a ~5
  - Deteriorando: aciertos disminuyen de ~9 a ~2
  - Oscilando:   aciertos fluctúan aleatoriamente en todo el rango

Configuración "prueba larga":
  - 50 estudiantes (12-13 por tipo de trayectoria)
  - 20 semanas por estudiante
  - Ruido gaussiano reducido (σ = 0.5) para estados más suaves
  - Total: 1000 observaciones

Uso:
    python generar_datos_sinteticos.py

Salida:
    datos_entrada.csv con columnas:
        estudiante_id, semana, aciertos, tiempo_decision, compartida
"""

import numpy as np
import pandas as pd

# Semilla para reproducibilidad
SEMILLA = 42
np.random.seed(SEMILLA)


def generar_datos(n_estudiantes=50, n_semanas=20, ruido=0.5):
    """
    Genera un dataset sintético largo con cuatro tipos de trayectorias.

    Parámetros
    ----------
    n_estudiantes : int
        Número total de estudiantes (por defecto 50).
        Se distribuyen equitativamente entre los 4 tipos de trayectoria.
    n_semanas : int
        Número de semanas por estudiante (por defecto 20).
    ruido : float
        Desviación estándar del ruido gaussiano añadido a los aciertos.
        Valores más altos producen trayectorias más ruidosas.

    Retorna
    -------
    df : pandas.DataFrame
        Dataset con columnas: estudiante_id, semana, aciertos,
        tiempo_decision, compartida.
    """
    filas = []

    for est in range(1, n_estudiantes + 1):
        # Asignar tipo de trayectoria cíclicamente
        tipo = (est - 1) % 4  # 0=mejorando, 1=estancado, 2=deteriorando, 3=oscilando

        # Cada estudiante tiene una "línea base" ligeramente distinta
        # para evitar que todos los del mismo tipo sean idénticos
        offset_estudiante = np.random.normal(0, 0.5)

        for sem in range(1, n_semanas + 1):
            # Progreso normalizado en [0, 1]
            progreso = (sem - 1) / (n_semanas - 1) if n_semanas > 1 else 0

            if tipo == 0:  # Mejorando: 2 → 9
                base = 2 + progreso * 7
            elif tipo == 1:  # Estancado: ~5
                base = 5
            elif tipo == 2:  # Deteriorando: 9 → 2
                base = 9 - progreso * 7
            else:  # Oscilando: aleatorio en [0, 10]
                base = np.random.uniform(0, 10)

            # Añadir offset del estudiante y ruido gaussiano
            valor = base + offset_estudiante + np.random.normal(0, ruido)
            aciertos = int(np.clip(valor, 0, 10))

            filas.append({
                "estudiante_id": f"E{est:03d}",
                "semana": sem,
                "aciertos": aciertos,
                "tiempo_decision": float(np.random.uniform(1, 10)),
                "compartida": int(np.random.randint(0, 2))
            })

    return pd.DataFrame(filas)


def imprimir_resumen(df, n_semanas):
    """Imprime un resumen de las trayectorias generadas."""
    print("\n" + "=" * 70)
    print("RESUMEN DEL DATASET GENERADO (PRUEBA LARGA)")
    print("=" * 70)
    print(f"Total de registros: {len(df)}")
    print(f"Estudiantes: {df['estudiante_id'].nunique()}")
    print(f"Semanas por estudiante: {n_semanas}")
    print(f"Rango de aciertos: [{df['aciertos'].min()}, {df['aciertos'].max()}]")

    # Distribución por categoría (bajo/medio/alto)
    def categoria(a):
        if a <= 3:
            return "bajo (0-3)"
        elif a <= 6:
            return "medio (4-6)"
        else:
            return "alto (7-10)"

    df = df.copy()
    df["categoria"] = df["aciertos"].apply(categoria)
    print("\nDistribución por categoría:")
    for cat in ["bajo (0-3)", "medio (4-6)", "alto (7-10)"]:
        n = (df["categoria"] == cat).sum()
        print(f"  {cat}: {n} ({100*n/len(df):.1f}%)")

    # Trayectorias de ejemplo (4 estudiantes, uno de cada tipo)
    print("\nTrayectorias de ejemplo (un estudiante por tipo):")
    print("-" * 70)
    for tipo_idx, tipo_nombre in enumerate(["Mejorando   ", "Estancado   ",
                                              "Deteriorando", "Oscilando   "]):
        est_id = f"E{tipo_idx + 1:03d}"
        grupo = df[df["estudiante_id"] == est_id].sort_values("semana")
        aciertos = grupo["aciertos"].tolist()
        print(f"  {est_id} ({tipo_nombre}): {aciertos}")

    # Estadísticas por tipo de trayectoria
    print("\nEstadísticas por tipo de trayectoria:")
    print("-" * 70)
    for tipo_idx, tipo_nombre in enumerate(["Mejorando   ", "Estancado   ",
                                              "Deteriorando", "Oscilando   "]):
        # Estudiantes de este tipo
        est_ids = [f"E{i:03d}" for i in range(tipo_idx + 1,
                                                df['estudiante_id'].nunique() + 1,
                                                4)]
        sub = df[df["estudiante_id"].isin(est_ids)]
        media = sub["aciertos"].mean()
        std = sub["aciertos"].std()
        print(f"  {tipo_nombre}: media = {media:.2f}, std = {std:.2f}, "
              f"n = {len(sub)}")


def main():
    print("=" * 70)
    print("GENERADOR DE DATOS SINTÉTICOS — PRUEBA LARGA")
    print("=" * 70)

    # Configuración de prueba larga
    N_ESTUDIANTES = 50
    N_SEMANAS = 20
    RUIDO = 0.5

    print(f"\nConfiguración:")
    print(f"  - {N_ESTUDIANTES} estudiantes")
    print(f"  - {N_SEMANAS} semanas por estudiante")
    print(f"  - Ruido gaussiano: σ = {RUIDO}")
    print(f"  - Total esperado: {N_ESTUDIANTES * N_SEMANAS} observaciones")
    print(f"  - 4 tipos de trayectoria (mejorando, estancado, deteriorando, oscilando)")

    df = generar_datos(n_estudiantes=N_ESTUDIANTES,
                        n_semanas=N_SEMANAS,
                        ruido=RUIDO)

    # Guardar en CSV
    archivo_salida = "datos_entrada.csv"
    df.to_csv(archivo_salida, index=False)
    print(f"\n✓ Dataset guardado en {archivo_salida}")

    # Resumen
    imprimir_resumen(df, n_semanas=N_SEMANAS)

    print("\n" + "=" * 70)
    print("PROCESO COMPLETADO")
    print("=" * 70)
    print(f"\nSiguiente paso: python alfabetizacion.py")


if __name__ == "__main__":
    main()
