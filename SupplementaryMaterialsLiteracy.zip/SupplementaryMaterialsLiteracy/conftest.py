"""
conftest.py
============================================================
Configuración global de pytest para el proyecto de
alfabetización mediática.

Este archivo:
  - Registra fixtures compartidos entre múltiples archivos de test.
  - Define marcadores personalizados (slow, integration, gpu).
  - Configura la semilla global para reproducibilidad.
  - Añade opciones de línea de comandos personalizadas.

No es necesario importarlo: pytest lo detecta automáticamente
al ejecutar `pytest` en el directorio del proyecto.
"""

import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# ============================================================
# 0. Asegurar que el módulo principal sea importable
# ============================================================
RAIZ_PROYECTO = Path(__file__).parent.resolve()
if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))


# ============================================================
# 1. Semilla global para reproducibilidad
# ============================================================
SEMILLA_TEST = 42


@pytest.fixture(autouse=True)
def semilla_global():
    """
    Fixture autouse: fija la semilla de NumPy antes de cada test
    y la restaura al final. Garantiza que los tests que usan
    np.random sin semilla explícita sean reproducibles.
    """
    estado_previo = np.random.get_state()
    np.random.seed(SEMILLA_TEST)
    yield
    np.random.set_state(estado_previo)


# ============================================================
# 2. Fixtures compartidos
# ============================================================
@pytest.fixture(scope="session")
def ruta_proyecto():
    """Ruta raíz del proyecto."""
    return RAIZ_PROYECTO


@pytest.fixture(scope="session")
def ruta_figuras(tmp_path_factory):
    """
    Carpeta temporal para figuras generadas durante los tests.
    Se elimina automáticamente al finalizar la sesión.
    """
    return tmp_path_factory.mktemp("figuras_test")


@pytest.fixture
def matriz_A_ejemplo_7_1():
    """
    Matriz de transición del Ejemplo 7.1 del manuscrito,
    en fracciones exactas para evitar errores de redondeo.
    """
    return np.array([
        [1/2, 3/10, 1/5],
        [1/5, 1/2, 3/10],
        [1/10, 1/5, 7/10]
    ])


@pytest.fixture
def matriz_B_ejemplo():
    """Matriz de emisión de ejemplo (3 estados × 3 observaciones)."""
    return np.array([
        [0.7, 0.2, 0.1],
        [0.2, 0.6, 0.2],
        [0.1, 0.3, 0.6]
    ])


@pytest.fixture
def modelo_hmm_falso(matriz_A_ejemplo_7_1, matriz_B_ejemplo):
    """
    Mock de un modelo HMM con los atributos mínimos necesarios
    para las funciones que no requieren hmmlearn.
    """
    class ModeloFalso:
        pass
    m = ModeloFalso()
    m.transmat_ = matriz_A_ejemplo_7_1
    m.emissionprob_ = matriz_B_ejemplo
    m.startprob_ = np.array([0.33, 0.34, 0.33])
    return m


@pytest.fixture
def df_sintetico_10x10():
    """
    DataFrame sintético con 10 estudiantes × 10 semanas.
    Reproducible con la semilla fija.
    """
    rng = np.random.default_rng(SEMILLA_TEST)
    filas = []
    for est in range(1, 11):
        for sem in range(1, 11):
            filas.append({
                "estudiante_id": f"E{est:03d}",
                "semana": sem,
                "aciertos": int(rng.integers(0, 11)),
                "tiempo_decision": float(rng.uniform(1, 10)),
                "compartida": int(rng.integers(0, 2))
            })
    return pd.DataFrame(filas)


@pytest.fixture
def df_csv_temporal(tmp_path, df_sintetico_10x10):
    """
    Guarda el DataFrame sintético en un CSV temporal y devuelve
    la ruta. Útil para tests que requieren leer_datos().
    """
    ruta = tmp_path / "datos_entrada.csv"
    df_sintetico_10x10.to_csv(ruta, index=False)
    return str(ruta)


# ============================================================
# 3. Marcadores personalizados
# ============================================================
def pytest_configure(config):
    """
    Registra marcadores personalizados para evitar warnings de
    pytest. Uso:
        @pytest.mark.slow
        @pytest.mark.integration
        @pytest.mark.requires_hmmlearn
    """
    config.addinivalue_line(
        "markers",
        "slow: tests que tardan más de 1 segundo (se pueden saltar con -m 'not slow')"
    )
    config.addinivalue_line(
        "markers",
        "integration: tests de integración que combinan varias funciones"
    )
    config.addinivalue_line(
        "markers",
        "requires_hmmlearn: tests que requieren la librería hmmlearn instalada"
    )


# ============================================================
# 4. Opciones de línea de comandos personalizadas
# ============================================================
def pytest_addoption(parser):
    """
    Añade opciones personalizadas:
        --run-slow      : ejecuta tests marcados como slow
        --run-integration : ejecuta tests marcados como integration
    """
    parser.addoption(
        "--run-slow",
        action="store_true",
        default=False,
        help="Ejecuta tests marcados como 'slow'"
    )
    parser.addoption(
        "--run-integration",
        action="store_true",
        default=False,
        help="Ejecuta tests marcados como 'integration'"
    )


def pytest_collection_modifyitems(config, items):
    """
    Salta tests marcados como slow o integration a menos que se
    pase la opción correspondiente.
    """
    if not config.getoption("--run-slow"):
        skip_slow = pytest.mark.skip(reason="Requiere --run-slow")
        for item in items:
            if "slow" in item.keywords:
                item.add_marker(skip_slow)

    if not config.getoption("--run-integration"):
        skip_int = pytest.mark.skip(reason="Requiere --run-integration")
        for item in items:
            if "integration" in item.keywords:
                item.add_marker(skip_int)


# ============================================================
# 5. Silenciar warnings ruidosos durante los tests
# ============================================================
def pytest_sessionstart(session):
    """Silencia warnings de convergencia de hmmlearn y otros."""
    warnings.filterwarnings(
        "ignore",
        category=DeprecationWarning,
        module="hmmlearn"
    )
    warnings.filterwarnings(
        "ignore",
        message=".*KMeans.*",
        category=UserWarning
    )


# ============================================================
# 6. Reporte de versión de dependencias al inicio
# ============================================================
def pytest_report_header(config):
    """Añade un encabezado con las versiones de las dependencias."""
    lineas = ["Dependencias del entorno de tests:"]
    for modulo in ["numpy", "scipy", "pandas", "matplotlib", "hmmlearn"]:
        try:
            mod = __import__(modulo)
            version = getattr(mod, "__version__", "desconocida")
            lineas.append(f"  - {modulo}: {version}")
        except ImportError:
            lineas.append(f"  - {modulo}: NO INSTALADO")
    return "\n".join(lineas)
