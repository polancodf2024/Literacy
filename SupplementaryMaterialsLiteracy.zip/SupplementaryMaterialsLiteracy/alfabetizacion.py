"""
Modelado de alfabetización mediática con HMM y Monte Carlo
===========================================================
Versión 5.1 — con solver de control óptimo, bootstrap robusto,
              análisis de sensibilidad, validación de monotonicidad
              y ajuste cuadrático de la curva de sensibilidad.
===========================================================
Cambios respecto a v5.0:
  - `_refit_hmm_rapido` repara filas de transmat_ con suma cero.
  - `resolver_control_optimo` tiene guarda contra división por cero
    y verifica finitud de E_opt.
  - `bootstrap_ci` implementa bootstrap paramétrico Dirichlet
    (rápido) y bootstrap por reajuste (riguroso, opcional con joblib).
  - Todas las rutinas verifican finitud antes de acumular resultados.
  - Reducción de N_BOOTSTRAP a 500 y N_INIT_BOOTSTRAP a 1.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from hmmlearn import hmm
from pathlib import Path
from scipy.optimize import minimize, curve_fit
import sys
import warnings
import time

warnings.filterwarnings("ignore", category=DeprecationWarning)

# Intentar importar joblib (opcional, solo para bootstrap por reajuste)
try:
    from joblib import Parallel, delayed
    _JOBLIB_DISPONIBLE = True
except ImportError:
    _JOBLIB_DISPONIBLE = False


# ============================================================
# Configuración global
# ============================================================
ARCHIVO_ENTRADA = "datos_entrada.csv"
ARCHIVO_SALIDA = "resultados.csv"
ARCHIVO_ESTADOS = "estados_inferidos.csv"
ARCHIVO_MATRICES_LATEX = "matrices_latex.txt"
ARCHIVO_OCP = "control_optimo.txt"
ARCHIVO_EXTENDIDO = "analisis_extendido.txt"
CARPETA_FIGURAS = Path("figuras")
CARPETA_FIGURAS.mkdir(exist_ok=True)

SEMILLA_GLOBAL = 42
np.random.seed(SEMILLA_GLOBAL)

UMBRAL_BAJO = 3
UMBRAL_MEDIO = 6

N_ESTUDIANTES_MC = 100_000
N_SEMANAS_MC = 10
SEMANA_INTERVENCION = 5
MAX_PASOS_MC = 10_000

N_INIT_HMM = 10
N_ITER_HMM = 200
TOL_HMM = 1e-4

TOL_ESTOCASTICIDAD = 1e-8
TOL_PROB_CERO = 1e-10
TOL_NORMA_CERO = 1e-12

# --- Parámetros de las rutinas nuevas ---
N_BOOTSTRAP = 500          # reducido de 2000 (suficiente para IC 95%)
N_INIT_BOOTSTRAP = 1       # reducido de 3 (solo aplica con metodo="refit")
BOOTSTRAP_METODO = "dirichlet"  # "dirichlet" (rápido) o "refit" (riguroso)
N_PERTURB = 1000
DELTA_PERTURB = 0.05
N_PUNTOS_MONOTONIA = 50
N_SIM_MONOTONIA = 5000
N_PUNTOS_SENS_CURVE = 12


# ============================================================
# 0. Utilidades
# ============================================================
def verificar_estocasticidad(M, nombre="matriz", tol=TOL_ESTOCASTICIDAD):
    M = np.asarray(M, dtype=float)
    if M.ndim != 2 or M.shape[0] != M.shape[1]:
        raise ValueError(f"{nombre}: no es cuadrada ({M.shape})")
    if np.any(M < -tol):
        raise ValueError(f"{nombre}: contiene entradas negativas")
    sumas = M.sum(axis=1)
    if not np.allclose(sumas, 1.0, atol=tol):
        raise ValueError(f"{nombre}: las filas no suman 1 ({sumas})")
    return True


def reparar_transmat(A, tol=1e-8):
    """Repara filas de una matriz de transición con suma cero."""
    A = np.asarray(A, dtype=float).copy()
    n = A.shape[0]
    sumas = A.sum(axis=1)
    for i in range(n):
        if sumas[i] < tol:
            A[i, :] = 1.0 / n
    # Clip a no negativo y renormalizar
    A = np.clip(A, 0.0, None)
    sumas = A.sum(axis=1, keepdims=True)
    sumas = np.where(sumas < tol, 1.0, sumas)
    return A / sumas


def imprimir_matriz_latex(M, nombre="A", decimales=4):
    M = np.asarray(M, dtype=float)
    filas, cols = M.shape
    lineas = [r"\begin{pmatrix}"]
    for i in range(filas):
        entradas = " & ".join(f"{M[i, j]:.{decimales}f}" for j in range(cols))
        lineas.append(f"    {entradas}" + (r" \\" if i < filas - 1 else ""))
    lineas.append(r"\end{pmatrix}")
    return f"% {nombre} =\n" + "\n".join(lineas)


def elegir_estado_verificador(modelo):
    medias = modelo.emissionprob_ @ np.array([0, 1, 2])
    return int(np.argmax(medias)), medias


# ============================================================
# 1. Leer datos
# ============================================================
def leer_datos(ruta):
    print(f"\n[1] Leyendo datos de {ruta}...")
    if not Path(ruta).exists():
        raise FileNotFoundError(f"No se encontró {ruta}")
    df = pd.read_csv(ruta)
    requeridas = {"estudiante_id", "semana", "aciertos",
                  "tiempo_decision", "compartida"}
    faltantes = requeridas - set(df.columns)
    if faltantes:
        raise ValueError(f"Faltan columnas: {faltantes}")
    if df["aciertos"].min() < 0 or df["aciertos"].max() > 10:
        raise ValueError("La columna 'aciertos' debe estar en [0, 10]")
    dup = df.duplicated(subset=["estudiante_id", "semana"]).sum()
    if dup > 0:
        raise ValueError(f"Hay {dup} filas duplicadas (estudiante-semana)")
    print(f"    Registros: {len(df)}")
    print(f"    Estudiantes: {df['estudiante_id'].nunique()}")
    print(f"    Semanas: {df['semana'].nunique()}")
    return df


# ============================================================
# 2. Discretizar
# ============================================================
def discretizar_observaciones(df, umbral_bajo=UMBRAL_BAJO,
                              umbral_medio=UMBRAL_MEDIO):
    print("\n[2] Discretizando observaciones...")
    if umbral_bajo >= umbral_medio:
        raise ValueError("umbral_bajo debe ser < umbral_medio")

    def categoria(aciertos):
        if aciertos <= umbral_bajo:
            return 0
        elif aciertos <= umbral_medio:
            return 1
        else:
            return 2

    df = df.copy()
    df["observacion"] = df["aciertos"].apply(categoria)
    for cat, nombre in enumerate(["bajo (0-3)", "medio (4-6)", "alto (7-10)"]):
        n = (df["observacion"] == cat).sum()
        print(f"      {nombre}: {n} ({100*n/len(df):.1f}%)")
    return df


# ============================================================
# 3. Ajustar HMM
# ============================================================
def ajustar_hmm(df, n_estados=3, n_init=N_INIT_HMM,
                n_iter=N_ITER_HMM, tol=TOL_HMM, verbose=True):
    if verbose:
        print(f"\n[3] Ajustando HMM de {n_estados} estados "
              f"({n_init} reinicializaciones)...")
    secuencias = []
    longitudes = []
    for est_id, grupo in df.groupby("estudiante_id"):
        grupo = grupo.sort_values("semana")
        secuencias.append(grupo["observacion"].values)
        longitudes.append(len(grupo))
    X = np.concatenate(secuencias).reshape(-1, 1)
    lengths = longitudes

    mejores_modelos = []
    info_inits = []
    for i in range(n_init):
        modelo = hmm.CategoricalHMM(
            n_components=n_estados, n_iter=n_iter, tol=tol,
            random_state=SEMILLA_GLOBAL + i,
            init_params="ste", params="ste"
        )
        try:
            modelo.fit(X, lengths)
            # Reparar transmat_ si es necesario
            modelo.transmat_ = reparar_transmat(modelo.transmat_)
            ll = modelo.monitor_.history[-1]
            mejores_modelos.append((ll, modelo))
            info_inits.append({
                "init": i, "log_likelihood": ll,
                "converged": modelo.monitor_.converged,
                "n_iter": len(modelo.monitor_.history)
            })
        except Exception as e:
            if verbose:
                print(f"    Init {i}: falló ({e})")
            info_inits.append({"init": i, "log_likelihood": np.nan,
                                "converged": False, "n_iter": 0})

    if not mejores_modelos:
        raise RuntimeError("Ninguna reinicialización convergió.")

    mejores_modelos.sort(key=lambda x: x[0], reverse=True)
    ll_mejor, modelo = mejores_modelos[0]
    info_inits = pd.DataFrame(info_inits)
    if verbose:
        print(f"\n    Mejor log-verosimilitud: {ll_mejor:.4f}")
        print(f"    Convergentes: {info_inits['converged'].sum()}/{n_init}")
    verificar_estocasticidad(modelo.transmat_, "A estimada")
    verificar_estocasticidad(modelo.emissionprob_, "B estimada")
    if verbose:
        print(f"\n    Matriz A:\n    {modelo.transmat_}")
        print(f"\n    Matriz B:\n    {modelo.emissionprob_}")
    return modelo, secuencias, lengths, info_inits


# ============================================================
# 4. Inferir estados
# ============================================================
def inferir_estados(modelo, secuencias, lengths):
    print("\n[4] Infiriendo estados ocultos con Viterbi...")
    estados_por_estudiante = []
    for i in range(len(lengths)):
        sec = secuencias[i].reshape(-1, 1)
        _, estados = modelo.decode(sec, algorithm="viterbi")
        estados_por_estudiante.append(estados)

    _, medias = elegir_estado_verificador(modelo)
    orden = np.argsort(medias)
    print(f"    Medias de emisión: {medias}")
    print(f"    Orden: {orden}")

    estados_reetiquetados = []
    for estados in estados_por_estudiante:
        nuevo = np.zeros_like(estados)
        for viejo, nuevo_idx in enumerate(orden):
            nuevo[estados == viejo] = nuevo_idx
        estados_reetiquetados.append(nuevo)
    return estados_reetiquetados


# ============================================================
# 5. Distribución estacionaria y tiempo de retorno
# ============================================================
def calcular_distribucion_estacionaria(A, tol=TOL_PROB_CERO):
    A = np.asarray(A, dtype=float)
    verificar_estocasticidad(A, "A en calcular_distribucion_estacionaria")
    n = A.shape[0]
    M = np.linalg.matrix_power(np.eye(n) + A, n - 1)
    if np.any(M <= 0):
        raise ValueError("La matriz A no es irreducible (no ergódica).")
    vals, vecs = np.linalg.eig(A.T)
    idx = np.argmin(np.abs(vals - 1.0))
    pi = np.real(vecs[:, idx])
    if pi.sum() < 0:
        pi = -pi
    pi = np.maximum(pi, 0.0)
    suma = pi.sum()
    if suma < tol:
        raise ValueError("No se pudo normalizar π.")
    return pi / suma


def calcular_tiempo_retorno(A, estado_objetivo, tol=TOL_PROB_CERO):
    pi = calcular_distribucion_estacionaria(A, tol=tol)
    if pi[estado_objetivo] < tol:
        raise ValueError(
            f"π_{estado_objetivo}* ≈ 0; estado transitorio/absorbente.")
    return 1.0 / pi[estado_objetivo], pi


def verificar_teorema_retorno(modelo, n_simulaciones=100_000,
                               max_pasos=MAX_PASOS_MC):
    print("\n[5] Verificando Teorema 4.1 (mean return time)...")
    estado_verificador, medias = elegir_estado_verificador(modelo)
    print(f"    Estado verificador: {estado_verificador} "
          f"(media = {medias[estado_verificador]:.4f})")
    E_teorico, pi = calcular_tiempo_retorno(
        modelo.transmat_, estado_objetivo=estado_verificador)
    print(f"    π* = {pi}")
    print(f"    E_{estado_verificador}[T_{estado_verificador}] "
          f"teórico = {E_teorico:.6f}")

    A = modelo.transmat_
    rng = np.random.default_rng(SEMILLA_GLOBAL)
    tiempos = np.zeros(n_simulaciones, dtype=int)
    truncados = 0
    for i in range(n_simulaciones):
        estado = estado_verificador
        estado = rng.choice(A.shape[0], p=A[estado])
        t = 1
        while estado != estado_verificador and t < max_pasos:
            estado = rng.choice(A.shape[0], p=A[estado])
            t += 1
        if t >= max_pasos:
            truncados += 1
        tiempos[i] = t

    E_empirico = tiempos.mean()
    SE = tiempos.std(ddof=1) / np.sqrt(n_simulaciones)
    print(f"    E_{estado_verificador}[T_{estado_verificador}] "
          f"empírico = {E_empirico:.6f} ± {SE:.6f}")
    if truncados > 0:
        print(f"    ADVERTENCIA: {truncados} trayectorias truncadas.")
    dif_rel = 100 * abs(E_empirico - E_teorico) / E_teorico
    print(f"    Diferencia relativa: {dif_rel:.2f}%")
    return E_teorico, E_empirico, SE


# ============================================================
# 5b. SOLVER DE CONTROL ÓPTIMO (Teorema 5.2) — ROBUSTO
# ============================================================
def resolver_control_optimo(modelo, epsilon=0.5, verbose=True):
    """
    Resuelve el problema de control óptimo del Teorema 5.2.
    Robusto frente a matrices degeneradas (filas con suma cero).
    """
    if verbose:
        print("\n[5b] Resolviendo el problema de control óptimo (Teorema 5.2)...")

    A0 = reparar_transmat(modelo.transmat_)
    estado_verificador, _ = elegir_estado_verificador(modelo)
    n = A0.shape[0]
    I0 = np.eye(n)

    def vector_a_matriz_estocastica(x):
        M = x.reshape(n, n)
        M = np.maximum(M, 0.0)
        sumas = M.sum(axis=1, keepdims=True)
        sumas = np.where(sumas < 1e-12, 1.0, sumas)
        return M / sumas

    def objetivo(x):
        I = vector_a_matriz_estocastica(x)
        A_prima = I @ A0
        A_prima = np.maximum(A_prima, 0.0)
        sumas = A_prima.sum(axis=1, keepdims=True)
        # GUARDA CONTRA DIVISIÓN POR CERO
        if np.any(sumas < 1e-10):
            return 1e6
        A_prima = A_prima / sumas
        if not np.allclose(A_prima.sum(axis=1), 1.0, atol=1e-8):
            return 1e6
        try:
            E, _ = calcular_tiempo_retorno(A_prima, estado_verificador)
        except Exception:
            return 1e6
        if not np.isfinite(E):
            return 1e6
        return E

    def restriccion_epsilon(x):
        I = vector_a_matriz_estocastica(x)
        return epsilon - np.sum(np.abs(I - I0))

    x0 = I0.flatten().copy()
    restricciones = [{"type": "ineq", "fun": restriccion_epsilon}]

    resultado = minimize(
        objetivo, x0,
        method="SLSQP",
        constraints=restricciones,
        options={"maxiter": 500, "ftol": 1e-8, "disp": False}
    )

    I_opt = vector_a_matriz_estocastica(resultado.x)
    E_opt = objetivo(resultado.x)

    if not np.isfinite(E_opt):
        raise RuntimeError(
            "resolver_control_optimo: E_opt no finito. "
            "El solver no encontró solución válida.")

    E_base, _ = calcular_tiempo_retorno(A0, estado_verificador)

    if verbose:
        print(f"    Éxito: {resultado.success}")
        print(f"    Iteraciones: {resultado.nit}")
        print(f"    ||I_opt - I_0||_1 = {np.sum(np.abs(I_opt - I0)):.6f} "
              f"(ε = {epsilon})")
        print(f"    E[T_3] base    = {E_base:.6f}")
        print(f"    E[T_3] óptimo  = {E_opt:.6f}")
        reduccion = 100 * (E_base - E_opt) / E_base
        print(f"    Reducción      = {reduccion:.2f}%")
        print(f"    Matriz I_opt:\n{I_opt}")

    info = {
        "success": resultado.success,
        "nit": resultado.nit,
        "E_base": E_base,
        "E_opt": E_opt,
        "reduccion_pct": 100 * (E_base - E_opt) / E_base,
        "epsilon": epsilon,
        "norma_I_menos_I0": np.sum(np.abs(I_opt - I0)),
        "estado_verificador": estado_verificador,
    }
    return I_opt, info


def simular_con_intervencion_optima(modelo, I_opt,
                                     n_estudiantes=N_ESTUDIANTES_MC,
                                     n_semanas=N_SEMANAS_MC,
                                     semilla=SEMILLA_GLOBAL):
    A0 = reparar_transmat(modelo.transmat_)
    pi = modelo.startprob_.copy()
    A_prima = I_opt @ A0
    A_prima = reparar_transmat(A_prima)
    estado_verificador, _ = elegir_estado_verificador(modelo)

    rng = np.random.default_rng(semilla)
    estados_finales = np.zeros(n_estudiantes, dtype=int)
    for i in range(n_estudiantes):
        estado = rng.choice(A0.shape[0], p=pi)
        for t in range(n_semanas):
            estado = rng.choice(A_prima.shape[0], p=A_prima[estado])
        estados_finales[i] = estado

    p = (estados_finales == estado_verificador).mean()
    SE = np.sqrt(p * (1 - p) / n_estudiantes)
    return {"p_verificador": p, "error_estandar": SE,
            "ic_inferior": p - 1.96 * SE, "ic_superior": p + 1.96 * SE}


# ============================================================
# 5c. BOOTSTRAP CI ROBUSTO
# ============================================================
def _refit_hmm_rapido(df, n_estados=3, n_init=N_INIT_BOOTSTRAP,
                       n_iter=N_ITER_HMM, tol=TOL_HMM, seed_offset=0):
    """
    Reajuste ligero del HMM para bootstrap.
    Repara filas de transmat_ con suma cero.
    """
    secuencias = []
    longitudes = []
    for _, grupo in df.groupby("estudiante_id"):
        grupo = grupo.sort_values("semana")
        secuencias.append(grupo["observacion"].values)
        longitudes.append(len(grupo))
    X = np.concatenate(secuencias).reshape(-1, 1)
    lengths = longitudes

    mejor_ll = -np.inf
    mejor_modelo = None
    for i in range(n_init):
        modelo = hmm.CategoricalHMM(
            n_components=n_estados, n_iter=n_iter, tol=tol,
            random_state=SEMILLA_GLOBAL + seed_offset + i,
            init_params="ste", params="ste"
        )
        try:
            modelo.fit(X, lengths)
            # Reparar transmat_ si es necesario
            A = np.asarray(modelo.transmat_, dtype=float)
            if A.shape != (n_estados, n_estados):
                continue
            modelo.transmat_ = reparar_transmat(A)
            if not np.allclose(modelo.transmat_.sum(axis=1), 1.0,
                               atol=1e-6):
                continue
            ll = modelo.monitor_.history[-1]
            if ll > mejor_ll:
                mejor_ll = ll
                mejor_modelo = modelo
        except Exception:
            continue
    if mejor_modelo is None:
        raise RuntimeError("Bootstrap: ningún reinicio convergió.")
    return mejor_modelo


def _una_replica_bootstrap(b, df, ids_unicos, epsilon, rng_seed):
    """Réplica individual del bootstrap por reajuste (para joblib)."""
    rng = np.random.default_rng(rng_seed)
    ids_boot = rng.choice(ids_unicos, size=len(ids_unicos), replace=True)
    df_boot = df[df["estudiante_id"].isin(ids_boot)].copy()
    df_boot["estudiante_id"] = (
        df_boot["estudiante_id"].astype(str) + "_" +
        df_boot.groupby("estudiante_id").cumcount().astype(str)
    )
    try:
        modelo_b = _refit_hmm_rapido(df_boot, seed_offset=b)
        _, info_b = resolver_control_optimo(modelo_b, epsilon=epsilon,
                                              verbose=False)
        if np.isfinite(info_b["E_opt"]):
            return info_b["E_opt"]
        return np.nan
    except Exception:
        return np.nan


def bootstrap_ci(df, modelo_base, epsilon=0.5, n_bootstrap=N_BOOTSTRAP,
                 alpha=0.05, verbose=True, metodo=BOOTSTRAP_METODO):
    """
    Bootstrap para IC al 95% de E_3[T_3(I*)].

    metodo : str
        - "dirichlet": bootstrap paramétrico sobre Â (rápido).
        - "refit":     reajuste completo del HMM (riguroso, paralelo).
    """
    if verbose:
        print(f"\n[5c] Bootstrap CI para E_3[T_3(I*)] "
              f"({n_bootstrap} réplicas, método='{metodo}')...")

    A_hat = reparar_transmat(modelo_base.transmat_)
    pi_hat = modelo_base.startprob_.copy()
    B_hat = modelo_base.emissionprob_.copy()
    n = A_hat.shape[0]
    rng = np.random.default_rng(SEMILLA_GLOBAL)

    T3_values = []
    fallos = 0
    t0 = time.time()

    # Pseudo-conteos para Dirichlet (proporcionales a Â)
    conteos = A_hat * 100.0

    if metodo == "refit" and _JOBLIB_DISPONIBLE and n_bootstrap >= 50:
        # Bootstrap paralelo por reajuste
        ids_unicos = df["estudiante_id"].unique()
        resultados = Parallel(n_jobs=-1, verbose=0)(
            delayed(_una_replica_bootstrap)(
                b, df, ids_unicos, epsilon, SEMILLA_GLOBAL + b)
            for b in range(n_bootstrap)
        )
        T3_values = [r for r in resultados if np.isfinite(r)]
        fallos = n_bootstrap - len(T3_values)
    else:
        # Bootstrap secuencial
        for b in range(n_bootstrap):
            try:
                if metodo == "dirichlet":
                    A_b = np.zeros_like(A_hat)
                    for i in range(n):
                        alpha_i = np.maximum(conteos[i], 1e-3)
                        A_b[i] = rng.dirichlet(alpha_i)
                    modelo_b = hmm.CategoricalHMM(n_components=n)
                    modelo_b.transmat_ = A_b
                    modelo_b.startprob_ = pi_hat.copy()
                    modelo_b.emissionprob_ = B_hat.copy()
                elif metodo == "refit":
                    ids_unicos = df["estudiante_id"].unique()
                    ids_boot = rng.choice(ids_unicos,
                                           size=len(ids_unicos),
                                           replace=True)
                    df_boot = df[df["estudiante_id"].isin(ids_boot)].copy()
                    df_boot["estudiante_id"] = (
                        df_boot["estudiante_id"].astype(str) + "_" +
                        df_boot.groupby("estudiante_id").cumcount().astype(str)
                    )
                    modelo_b = _refit_hmm_rapido(df_boot, seed_offset=b)
                else:
                    raise ValueError(f"Método desconocido: {metodo}")

                _, info_b = resolver_control_optimo(
                    modelo_b, epsilon=epsilon, verbose=False)
                if np.isfinite(info_b["E_opt"]):
                    T3_values.append(info_b["E_opt"])
                else:
                    fallos += 1
            except Exception:
                fallos += 1
                continue

            if verbose and (b + 1) % max(1, n_bootstrap // 10) == 0:
                dt = time.time() - t0
                print(f"    Réplica {b+1}/{n_bootstrap} "
                      f"({dt:.1f}s, fallos={fallos})")

    if not T3_values:
        raise RuntimeError("Bootstrap: ninguna réplica válida.")

    T3_values = np.array(T3_values)
    media = T3_values.mean()
    std = T3_values.std(ddof=1)
    ic_low = np.percentile(T3_values, 100 * alpha / 2)
    ic_high = np.percentile(T3_values, 100 * (1 - alpha / 2))

    if verbose:
        print(f"    Media bootstrap: {media:.6f}")
        print(f"    Desv. estándar: {std:.6f}")
        print(f"    IC {100*(1-alpha):.0f}%: [{ic_low:.6f}, {ic_high:.6f}]")
        print(f"    Fallos: {fallos}/{n_bootstrap}")

    return {
        "media": media, "std": std,
        "ic_inferior": ic_low, "ic_superior": ic_high,
        "valores": T3_values, "fallos": fallos,
        "n_bootstrap": n_bootstrap, "metodo": metodo
    }


# ============================================================
# 5d. SENSIBILIDAD DE I* FRENTE A PERTURBACIONES EN Â
# ============================================================
def sensitivity_analysis(modelo, epsilon=0.5, n_perturb=N_PERTURB,
                          delta=DELTA_PERTURB, verbose=True):
    """
    Perturba Â con ruido multiplicativo uniforme ±delta y resuelve el
    OCP en cada réplica. Mide la estabilidad de I* y E_3[T_3(I*)].
    """
    if verbose:
        print(f"\n[5d] Análisis de robustez de I* "
              f"({n_perturb} perturbaciones, δ = {delta:.2%})...")

    A_hat = reparar_transmat(modelo.transmat_)
    rng = np.random.default_rng(SEMILLA_GLOBAL)
    I_stars = []
    T3_values = []
    fallos = 0
    t0 = time.time()

    for k in range(n_perturb):
        ruido = rng.uniform(-delta, delta, size=A_hat.shape)
        A_pert = A_hat * (1 + ruido)
        A_pert = np.clip(A_pert, 1e-6, None)
        A_pert = reparar_transmat(A_pert)

        modelo_pert = hmm.CategoricalHMM(n_components=A_hat.shape[0])
        modelo_pert.transmat_ = A_pert
        modelo_pert.startprob_ = modelo.startprob_.copy()
        modelo_pert.emissionprob_ = modelo.emissionprob_.copy()

        try:
            I_b, info_b = resolver_control_optimo(
                modelo_pert, epsilon=epsilon, verbose=False)
            if np.isfinite(info_b["E_opt"]):
                I_stars.append(I_b)
                T3_values.append(info_b["E_opt"])
            else:
                fallos += 1
        except Exception:
            fallos += 1
            continue

        if verbose and (k + 1) % max(1, n_perturb // 10) == 0:
            dt = time.time() - t0
            print(f"    Perturbación {k+1}/{n_perturb} "
                  f"({dt:.1f}s, fallos={fallos})")

    if not T3_values:
        raise RuntimeError("sensitivity_analysis: ninguna réplica válida.")

    I_stars = np.array(I_stars)
    T3_values = np.array(T3_values)
    I_mean = I_stars.mean(axis=0)
    I_std = I_stars.std(axis=0)
    T3_mean = T3_values.mean()
    T3_std = T3_values.std(ddof=1)
    T3_ic = np.percentile(T3_values, [2.5, 97.5])

    if verbose:
        print(f"    I* media:\n{I_mean}")
        print(f"    I* desv. estándar:\n{I_std}")
        print(f"    E_3[T_3(I*)] = {T3_mean:.6f} ± {T3_std:.6f}")
        print(f"    IC 95%: [{T3_ic[0]:.6f}, {T3_ic[1]:.6f}]")
        print(f"    Fallos: {fallos}/{n_perturb}")

    return {
        "I_mean": I_mean, "I_std": I_std,
        "T3_mean": T3_mean, "T3_std": T3_std,
        "T3_ic_inferior": T3_ic[0], "T3_ic_superior": T3_ic[1],
        "I_stars": I_stars, "T3_values": T3_values,
        "n_perturb": n_perturb, "delta": delta, "fallos": fallos
    }


# ============================================================
# 5e. VALIDACIÓN DE MONOTONICIDAD (Prop. 6.1)
# ============================================================
def _simular_reach_probability(A, estado_inicial, estado_objetivo,
                                 T=10, n_sim=5000, rng=None):
    """Probabilidad empírica de alcanzar `estado_objetivo` en T pasos."""
    if rng is None:
        rng = np.random.default_rng(SEMILLA_GLOBAL)
    n = A.shape[0]
    exitos = 0
    for _ in range(n_sim):
        estado = estado_inicial
        for _ in range(T):
            estado = rng.choice(n, p=A[estado])
        if estado == estado_objetivo:
            exitos += 1
    return exitos / n_sim


def _renormalizar_fila(A, fila, col_objetivo, nuevo_valor):
    """
    Modifica A[fila, col_objetivo] = nuevo_valor y renormaliza la fila
    repartiendo el cambio proporcionalmente entre las otras entradas.
    """
    A = A.copy()
    viejo = A[fila, col_objetivo]
    delta = nuevo_valor - viejo
    otras = [j for j in range(A.shape[1]) if j != col_objetivo]
    peso_total = A[fila, otras].sum()
    if peso_total < 1e-12:
        for j in otras:
            A[fila, j] = max(0.0, A[fila, j] - delta / len(otras))
    else:
        for j in otras:
            A[fila, j] = max(
                0.0,
                A[fila, j] - delta * A[fila, j] / peso_total
            )
    A[fila, col_objetivo] = nuevo_valor
    return reparar_transmat(A)


def validate_monotonicity(modelo, T=N_SEMANAS_MC,
                           n_points=N_PUNTOS_MONOTONIA,
                           n_sim=N_SIM_MONOTONIA, verbose=True):
    """
    Verifica numéricamente la Proposición 6.1 con la matriz Â ajustada.
    """
    if verbose:
        print(f"\n[5e] Validando Proposición 6.1 (monotonicidad) "
              f"con Â ajustada...")

    A_hat = reparar_transmat(modelo.transmat_)
    _, medias = elegir_estado_verificador(modelo)
    estado_credulo = int(np.argmin(medias))
    estado_verificador = int(np.argmax(medias))
    estado_esceptico = int(np.setdiff1d([0, 1, 2],
                            [estado_credulo, estado_verificador])[0])

    rng = np.random.default_rng(SEMILLA_GLOBAL)

    # --- Barrido de a_13 (crédulo → verificador) ---
    a13_grid = np.linspace(0.01, 0.50, n_points)
    probs_13 = []
    for a13 in a13_grid:
        A_mod = _renormalizar_fila(A_hat, estado_credulo,
                                    estado_verificador, a13)
        p = _simular_reach_probability(
            A_mod, estado_inicial=estado_credulo,
            estado_objetivo=estado_verificador,
            T=T, n_sim=n_sim, rng=rng)
        probs_13.append(p)
    probs_13 = np.array(probs_13)
    diffs_13 = np.diff(probs_13)
    monotona_13 = bool(np.all(diffs_13 >= -1e-3))

    # --- Barrido de a_23 (escéptico → verificador) ---
    a23_grid = np.linspace(0.01, 0.50, n_points)
    probs_23 = []
    for a23 in a23_grid:
        A_mod = _renormalizar_fila(A_hat, estado_esceptico,
                                    estado_verificador, a23)
        p = _simular_reach_probability(
            A_mod, estado_inicial=estado_esceptico,
            estado_objetivo=estado_verificador,
            T=T, n_sim=n_sim, rng=rng)
        probs_23.append(p)
    probs_23 = np.array(probs_23)
    diffs_23 = np.diff(probs_23)
    monotona_23 = bool(np.all(diffs_23 >= -1e-3))

    if verbose:
        print(f"    a_13: min diff = {diffs_13.min():+.5f}  "
              f"→ monótona: {monotona_13}")
        print(f"    a_23: min diff = {diffs_23.min():+.5f}  "
              f"→ monótona: {monotona_23}")

    return {
        "a13_grid": a13_grid, "probs_13": probs_13,
        "diffs_13": diffs_13, "monotona_13": monotona_13,
        "a23_grid": a23_grid, "probs_23": probs_23,
        "diffs_23": diffs_23, "monotona_23": monotona_23,
        "T": T, "n_sim": n_sim,
        "estado_credulo": estado_credulo,
        "estado_esceptico": estado_esceptico,
        "estado_verificador": estado_verificador
    }


# ============================================================
# 5f. AJUSTE CUADRÁTICO DE LA CURVA DE SENSIBILIDAD
# ============================================================
def fit_sensitivity_curve(a_grid, probs, T=N_SEMANAS_MC, verbose=True):
    """
    Ajusta la curva de sensibilidad a un modelo cuadrático
    p(a) = c0 + c1*a + c2*a^2 y reporta R², punto de saturación
    y comparación con la cota de unión 1 - (1 - a)^T.
    """
    if verbose:
        print(f"\n[5f] Ajuste cuadrático de la curva de sensibilidad...")

    def quad(a, c0, c1, c2):
        return c0 + c1 * a + c2 * a ** 2

    try:
        popt, pcov = curve_fit(quad, a_grid, probs, p0=[0.4, 0.5, -0.5])
        perr = np.sqrt(np.diag(pcov))
    except Exception as e:
        if verbose:
            print(f"    Falló el ajuste cuadrático: {e}")
        return None

    pred = quad(a_grid, *popt)
    ss_res = np.sum((probs - pred) ** 2)
    ss_tot = np.sum((probs - probs.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan

    a_sat = -popt[1] / (2 * popt[2]) if popt[2] < 0 else None
    p_sat = quad(a_sat, *popt) if a_sat is not None else None

    union_bound = 1 - (1 - a_grid) ** T

    if verbose:
        print(f"    Coeficientes: c0 = {popt[0]:.4f} ± {perr[0]:.4f}, "
              f"c1 = {popt[1]:.4f} ± {perr[1]:.4f}, "
              f"c2 = {popt[2]:.4f} ± {perr[2]:.4f}")
        print(f"    R² = {r2:.4f}")
        if a_sat is not None:
            print(f"    Punto de saturación: a* = {a_sat:.4f}, "
                  f"p(a*) = {p_sat:.4f}")
        print(f"    Cota de unión (T={T}) en a=0.5: "
              f"{1 - (1 - 0.5)**T:.4f}")

    return {
        "coeffs": popt, "coeffs_err": perr,
        "R2": r2, "a_saturacion": a_sat, "p_saturacion": p_sat,
        "union_bound": union_bound,
        "a_grid": a_grid, "probs": probs, "pred": pred,
        "T": T
    }


# ============================================================
# 6. Monte Carlo con intervención en t=5
# ============================================================
def construir_matriz_intervencion(A_base, escenario):
    A = np.asarray(A_base, dtype=float).copy()
    if escenario == "tutoria":
        A[0, 1] *= 1.5
        A[1, 2] *= 1.5
    elif escenario == "gamificacion":
        A[0, 2] *= 2.0
    elif escenario != "sin_intervencion":
        raise ValueError(f"Escenario desconocido: {escenario}")
    A = reparar_transmat(A)
    verificar_estocasticidad(A, f"A_{escenario}")
    return A


def simular_monte_carlo(modelo, n_estudiantes=N_ESTUDIANTES_MC,
                        n_semanas=N_SEMANAS_MC,
                        semana_intervencion=SEMANA_INTERVENCION,
                        escenario="sin_intervencion",
                        semilla=SEMILLA_GLOBAL):
    A_base = reparar_transmat(modelo.transmat_)
    pi = modelo.startprob_.copy()
    A_intervenida = construir_matriz_intervencion(A_base, escenario)
    estado_verificador, _ = elegir_estado_verificador(modelo)

    rng = np.random.default_rng(semilla)
    estados_finales = np.zeros(n_estudiantes, dtype=int)
    for i in range(n_estudiantes):
        estado = rng.choice(A_base.shape[0], p=pi)
        for t in range(n_semanas):
            A_actual = A_intervenida if t >= semana_intervencion else A_base
            estado = rng.choice(A_actual.shape[0], p=A_actual[estado])
        estados_finales[i] = estado

    p = (estados_finales == estado_verificador).mean()
    SE = np.sqrt(p * (1 - p) / n_estudiantes)
    return {"escenario": escenario, "p_verificador": p,
            "error_estandar": SE,
            "ic_inferior": p - 1.96 * SE,
            "ic_superior": p + 1.96 * SE,
            "estados_finales": estados_finales}


# ============================================================
# 7. Cota de gamificación
# ============================================================
def verificar_cota_gamificacion(a13=0.2, alpha=1.5, T=5,
                                 n_simulaciones=200_000,
                                 semilla=SEMILLA_GLOBAL):
    print("\n[7] Verificando Corolario 6.1 (cota de gamificación)...")
    if alpha * a13 > 1:
        raise ValueError("α·a13 debe ser ≤ 1")
    cota = 1 - (1 - alpha * a13) ** T
    print(f"    Cota teórica: {cota:.5f}")

    rng = np.random.default_rng(semilla)
    exitos = 0
    for _ in range(n_simulaciones):
        for t in range(T):
            if rng.random() < alpha * a13:
                exitos += 1
                break
    p = exitos / n_simulaciones
    SE = np.sqrt(p * (1 - p) / n_simulaciones)
    print(f"    P(empírica): {p:.5f} ± {SE:.5f}")
    print(f"    ¿Se cumple? {'SÍ' if p >= cota - 1e-2 else 'NO'}")
    return cota, p


# ============================================================
# 8. Comparación con BioPython (demo)
# ============================================================
def calcular_similitud_biopython(vectores, tol_norma=TOL_NORMA_CERO):
    X = np.asarray(vectores, dtype=float)
    if X.ndim != 2:
        raise ValueError("'vectores' debe ser una matriz 2D (n, d)")
    n = X.shape[0]
    medias = X.mean(axis=0)
    desv = X.std(axis=0)
    desv_segura = np.where(desv < tol_norma, 1.0, desv)
    Xz = (X - medias) / desv_segura
    normas = np.linalg.norm(Xz, axis=1)
    S = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(n):
            ni, nj = normas[i], normas[j]
            if ni < tol_norma and nj < tol_norma:
                S[i, j] = 1.0 if np.allclose(X[i], X[j],
                                              atol=tol_norma) else 0.0
            elif ni < tol_norma or nj < tol_norma:
                S[i, j] = 0.0
            else:
                cos = float(np.dot(Xz[i], Xz[j]) / (ni * nj))
                cos = max(-1.0, min(1.0, cos))
                S[i, j] = (1.0 + cos) / 2.0
    np.fill_diagonal(S, 1.0)
    return S


def comparar_con_biopython(df):
    print("\n[8] Comparación con BioPython ProtParam (demo)...")
    df_est = df.groupby("estudiante_id")[
        ["aciertos", "tiempo_decision", "compartida"]].mean()
    S = calcular_similitud_biopython(df_est.values)
    assert np.allclose(np.diag(S), 1.0)
    assert np.all(S >= -1e-10) and np.all(S <= 1 + 1e-10)
    print(f"    Matriz de similitud (3x3):\n{S[:3, :3]}")
    return S


# ============================================================
# 9. Figuras
# ============================================================
def generar_figuras(estados_por_estudiante, modelo, df,
                     fit_result=None, monotonia_result=None):
    print("\n[9] Generando figuras...")

    # --- Figura 1: Trayectorias ---
    fig, ax = plt.subplots(figsize=(8, 4))
    colores = ["#d62728", "#ff7f0e", "#2ca02c", "#1f77b4", "#9467bd"]
    nombres = ["Credulous", "Passive skeptic", "Active verifier"]
    for i in range(min(5, len(estados_por_estudiante))):
        estados = estados_por_estudiante[i]
        ax.plot(range(1, len(estados)+1), estados, "o-",
                color=colores[i], label=f"Student {i+1}",
                markersize=6, linewidth=1.5)
    ax.set_xlabel("Week")
    ax.set_ylabel("Hidden state")
    ax.set_yticks([0, 1, 2])
    ax.set_yticklabels(nombres)
    ax.legend(loc="center left", bbox_to_anchor=(1, 0.5))
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(CARPETA_FIGURAS / "trayectorias.pdf", dpi=300,
                bbox_inches="tight")
    plt.close()

    # --- Figura 2: Sensibilidad con ajuste cuadrático ---
    fig, ax = plt.subplots(figsize=(7, 4.5))
    A_base = reparar_transmat(modelo.transmat_)
    estado_verificador, _ = elegir_estado_verificador(modelo)
    _, medias = elegir_estado_verificador(modelo)
    estado_credulo = int(np.argmin(medias))

    tasas = np.linspace(0.05, 0.50, N_PUNTOS_SENS_CURVE)
    probs, SEs = [], []
    n_sim = 100_000
    for tasa in tasas:
        A = A_base.copy()
        A[estado_credulo, estado_verificador] = tasa
        A[estado_credulo] = A[estado_credulo] / A[estado_credulo].sum()
        A = reparar_transmat(A)
        verificar_estocasticidad(A, f"A(tasa={tasa:.2f})")
        rng = np.random.default_rng(SEMILLA_GLOBAL)
        exitos = 0
        for _ in range(n_sim):
            estado = rng.choice(3, p=modelo.startprob_)
            for t in range(10):
                estado = rng.choice(3, p=A[estado])
            if estado == estado_verificador:
                exitos += 1
        p = exitos / n_sim
        probs.append(p)
        SEs.append(np.sqrt(p * (1 - p) / n_sim))
    probs = np.array(probs)
    SEs = np.array(SEs)

    ax.errorbar(tasas, probs, yerr=1.96*SEs, fmt="o-",
                color="#1f77b4", linewidth=2, capsize=3,
                label="Simulación MC")

    if fit_result is not None:
        a_fino = np.linspace(tasas.min(), tasas.max(), 200)
        c0, c1, c2 = fit_result["coeffs"]
        ax.plot(a_fino, c0 + c1*a_fino + c2*a_fino**2,
                "--", color="#d62728", linewidth=1.8,
                label=f"Ajuste cuadrático ($R^2$ = {fit_result['R2']:.4f})")
        if fit_result["a_saturacion"] is not None and \
                tasas.min() <= fit_result["a_saturacion"] <= tasas.max():
            ax.axvline(fit_result["a_saturacion"], color="gray",
                       linestyle=":", alpha=0.6,
                       label=f"$a^*$ = {fit_result['a_saturacion']:.3f}")

    ax.set_xlabel("Learning rate $a_{\\mathrm{cred,ver}}$")
    ax.set_ylabel("$\\mathbb{P}(s_{10} = s_3)$")
    ax.grid(alpha=0.3)
    ax.legend(loc="lower right", fontsize=8)
    plt.tight_layout()
    plt.savefig(CARPETA_FIGURAS / "sensibilidad.pdf", dpi=300,
                bbox_inches="tight")
    plt.close()

    # --- Figura 3: Validación de monotonicidad ---
    if monotonia_result is not None:
        fig, axes = plt.subplots(1, 2, figsize=(11, 4))
        axes[0].plot(monotonia_result["a13_grid"],
                     monotonia_result["probs_13"], "o-",
                     color="#1f77b4", linewidth=1.8)
        axes[0].set_xlabel("$a_{13}$ (cred → ver)")
        axes[0].set_ylabel("$\\mathbb{P}(s_{10} = s_3)$")
        axes[0].set_title(f"a₁₃ sweep (monótona: "
                          f"{monotonia_result['monotona_13']})")
        axes[0].grid(alpha=0.3)

        axes[1].plot(monotonia_result["a23_grid"],
                     monotonia_result["probs_23"], "s-",
                     color="#2ca02c", linewidth=1.8)
        axes[1].set_xlabel("$a_{23}$ (skeptic → ver)")
        axes[1].set_ylabel("$\\mathbb{P}(s_{10} = s_3)$")
        axes[1].set_title(f"a₂₃ sweep (monótona: "
                          f"{monotonia_result['monotona_23']})")
        axes[1].grid(alpha=0.3)

        plt.tight_layout()
        plt.savefig(CARPETA_FIGURAS / "monotonicidad.pdf", dpi=300,
                    bbox_inches="tight")
        plt.close()

    print(f"    Figuras guardadas en {CARPETA_FIGURAS}/")


# ============================================================
# 10. Guardar resultados
# ============================================================
def guardar_resultados(df, estados_por_estudiante, resultados_mc,
                       modelo, info_inits, I_opt, info_ocp,
                       bootstrap_res=None, sensitivity_res=None,
                       monotonia_res=None, fit_res=None):
    print(f"\n[10] Guardando resultados...")

    df_mc = pd.DataFrame([{
        "escenario": r["escenario"],
        "p_verificador": r["p_verificador"],
        "error_estandar": r["error_estandar"],
        "ic_inferior": r["ic_inferior"],
        "ic_superior": r["ic_superior"]
    } for r in resultados_mc])
    df_mc.to_csv(ARCHIVO_SALIDA, index=False)

    df_estados = []
    idx = 0
    for est_id, grupo in df.groupby("estudiante_id"):
        grupo = grupo.sort_values("semana")
        estados = estados_por_estudiante[idx]
        for semana, estado in zip(grupo["semana"].values, estados):
            df_estados.append({"estudiante_id": est_id,
                                "semana": semana,
                                "estado_inferido": int(estado)})
        idx += 1
    pd.DataFrame(df_estados).to_csv(ARCHIVO_ESTADOS, index=False)

    with open(ARCHIVO_MATRICES_LATEX, "w") as f:
        f.write("% Matrices estimadas por el HMM\n")
        f.write(imprimir_matriz_latex(modelo.transmat_, "A") + "\n\n")
        f.write(imprimir_matriz_latex(modelo.emissionprob_, "B") + "\n\n")
        f.write("% Distribución inicial\n")
        f.write("\\pi = (" +
                ", ".join(f"{p:.4f}" for p in modelo.startprob_) + ")\n\n")
        f.write("% Resultados de las reinicializaciones\n")
        f.write(info_inits.to_string(index=False))

    with open(ARCHIVO_OCP, "w") as f:
        f.write("SOLUCIÓN DEL PROBLEMA DE CONTROL ÓPTIMO\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Estado verificador: {info_ocp['estado_verificador']}\n")
        f.write(f"epsilon: {info_ocp['epsilon']}\n")
        f.write(f"Éxito del solver: {info_ocp['success']}\n")
        f.write(f"Iteraciones: {info_ocp['nit']}\n")
        f.write(f"||I_opt - I_0||_1: {info_ocp['norma_I_menos_I0']:.6f}\n")
        f.write(f"E[T_3] base: {info_ocp['E_base']:.6f}\n")
        f.write(f"E[T_3] óptimo: {info_ocp['E_opt']:.6f}\n")
        f.write(f"Reducción: {info_ocp['reduccion_pct']:.2f}%\n\n")
        f.write("Matriz I_opt:\n")
        f.write(np.array2string(I_opt, precision=4, suppress_small=True))

    # --- Archivo de análisis extendido ---
    with open(ARCHIVO_EXTENDIDO, "w") as f:
        f.write("ANÁLISIS EXTENDIDO\n")
        f.write("=" * 60 + "\n\n")

        if bootstrap_res is not None:
            f.write("1. BOOTSTRAP CI para E_3[T_3(I*)]\n")
            f.write("-" * 60 + "\n")
            f.write(f"Método: {bootstrap_res.get('metodo', 'N/A')}\n")
            f.write(f"N réplicas: {bootstrap_res['n_bootstrap']}\n")
            f.write(f"Fallos: {bootstrap_res['fallos']}\n")
            f.write(f"Media: {bootstrap_res['media']:.6f}\n")
            f.write(f"Desv. estándar: {bootstrap_res['std']:.6f}\n")
            f.write(f"IC 95%: [{bootstrap_res['ic_inferior']:.6f}, "
                    f"{bootstrap_res['ic_superior']:.6f}]\n\n")

        if sensitivity_res is not None:
            f.write("2. ROBUSTEZ DE I* FRENTE A PERTURBACIONES\n")
            f.write("-" * 60 + "\n")
            f.write(f"N perturbaciones: {sensitivity_res['n_perturb']}\n")
            f.write(f"δ: {sensitivity_res['delta']:.4f}\n")
            f.write(f"Fallos: {sensitivity_res['fallos']}\n")
            f.write(f"E_3[T_3(I*)] = {sensitivity_res['T3_mean']:.6f} "
                    f"± {sensitivity_res['T3_std']:.6f}\n")
            f.write(f"IC 95%: [{sensitivity_res['T3_ic_inferior']:.6f}, "
                    f"{sensitivity_res['T3_ic_superior']:.6f}]\n")
            f.write("I* media:\n")
            f.write(np.array2string(sensitivity_res["I_mean"],
                                     precision=4, suppress_small=True))
            f.write("\n\nI* desv. estándar:\n")
            f.write(np.array2string(sensitivity_res["I_std"],
                                     precision=4, suppress_small=True))
            f.write("\n\n")

        if monotonia_res is not None:
            f.write("3. VALIDACIÓN DE MONOTONICIDAD (Prop. 6.1)\n")
            f.write("-" * 60 + "\n")
            f.write(f"a_13: min diff = "
                    f"{monotonia_res['diffs_13'].min():+.5f}  "
                    f"→ monótona: {monotonia_res['monotona_13']}\n")
            f.write(f"a_23: min diff = "
                    f"{monotonia_res['diffs_23'].min():+.5f}  "
                    f"→ monótona: {monotonia_res['monotona_23']}\n\n")

        if fit_res is not None:
            f.write("4. AJUSTE CUADRÁTICO DE LA CURVA DE SENSIBILIDAD\n")
            f.write("-" * 60 + "\n")
            c0, c1, c2 = fit_res["coeffs"]
            f.write(f"p(a) = {c0:.4f} + {c1:.4f}*a + {c2:.4f}*a^2\n")
            f.write(f"R² = {fit_res['R2']:.4f}\n")
            if fit_res["a_saturacion"] is not None:
                f.write(f"Punto de saturación: a* = "
                        f"{fit_res['a_saturacion']:.4f}, "
                        f"p(a*) = {fit_res['p_saturacion']:.4f}\n")
            f.write("\n")

    print(f"    {ARCHIVO_SALIDA}")
    print(f"    {ARCHIVO_ESTADOS}")
    print(f"    {ARCHIVO_MATRICES_LATEX}")
    print(f"    {ARCHIVO_OCP}")
    print(f"    {ARCHIVO_EXTENDIDO}")


# ============================================================
# 11. Main
# ============================================================
def main():
    print("=" * 70)
    print("MODELADO DE ALFABETIZACIÓN MEDIÁTICA CON HMM Y MONTE CARLO")
    print("Versión 5.1 — bootstrap robusto, sensibilidad, monotonicidad")
    print("=" * 70)

    try:
        df = leer_datos(ARCHIVO_ENTRADA)
    except (FileNotFoundError, ValueError) as e:
        print(f"\nERROR: {e}")
        sys.exit(1)

    df = discretizar_observaciones(df)
    modelo, secuencias, lengths, info_inits = ajustar_hmm(df, n_estados=3)
    estados = inferir_estados(modelo, secuencias, lengths)

    E_teo, E_emp, SE_emp = verificar_teorema_retorno(modelo)

    # --- Resolver el OCP ---
    I_opt, info_ocp = resolver_control_optimo(modelo, epsilon=0.5)

    # --- Simular con la intervención óptima ---
    print("\n[6b] Simulando con la intervención óptima...")
    r_opt = simular_con_intervencion_optima(modelo, I_opt)
    print(f"    P(verificador | I_opt) = "
          f"{r_opt['p_verificador']:.4f} ± {r_opt['error_estandar']:.4f}")

    print("\n[6] Simulación de Monte Carlo...")
    resultados_mc = []
    for escenario in ["sin_intervencion", "tutoria", "gamificacion"]:
        r = simular_monte_carlo(modelo, escenario=escenario)
        resultados_mc.append(r)
        print(f"    {escenario:20s}: P(verificador) = "
              f"{r['p_verificador']:.4f} ± {r['error_estandar']:.4f}")

    verificar_cota_gamificacion()
    comparar_con_biopython(df)

    # --- RUTINAS EXTENDIDAS ---
    print("\n" + "=" * 70)
    print("RUTINAS EXTENDIDAS")
    print("=" * 70)

    # 1. Bootstrap CI
    bootstrap_res = None
    try:
        bootstrap_res = bootstrap_ci(df, modelo, epsilon=0.5,
                                       n_bootstrap=N_BOOTSTRAP,
                                       metodo=BOOTSTRAP_METODO)
    except Exception as e:
        print(f"    ERROR en bootstrap_ci: {e}")

    # 2. Robustez de I*
    sensitivity_res = None
    try:
        sensitivity_res = sensitivity_analysis(
            modelo, epsilon=0.5, n_perturb=N_PERTURB,
            delta=DELTA_PERTURB)
    except Exception as e:
        print(f"    ERROR en sensitivity_analysis: {e}")

    # 3. Validación de monotonicidad
    monotonia_res = None
    try:
        monotonia_res = validate_monotonicity(modelo)
    except Exception as e:
        print(f"    ERROR en validate_monotonicity: {e}")

    # 4. Ajuste cuadrático de la curva de sensibilidad
    fit_res = None
    if monotonia_res is not None:
        try:
            fit_res = fit_sensitivity_curve(
                monotonia_res["a13_grid"], monotonia_res["probs_13"])
        except Exception as e:
            print(f"    ERROR en fit_sensitivity_curve: {e}")

    # --- Figuras ---
    generar_figuras(estados, modelo, df,
                     fit_result=fit_res,
                     monotonia_result=monotonia_res)

    # --- Guardar resultados ---
    guardar_resultados(df, estados, resultados_mc, modelo, info_inits,
                       I_opt, info_ocp,
                       bootstrap_res=bootstrap_res,
                       sensitivity_res=sensitivity_res,
                       monotonia_res=monotonia_res,
                       fit_res=fit_res)

    print("\n" + "=" * 70)
    print("PROCESO COMPLETADO")
    print("=" * 70)


if __name__ == "__main__":
    main()
