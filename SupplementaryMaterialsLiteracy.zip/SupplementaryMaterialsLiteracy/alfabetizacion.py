"""
Modelado de alfabetización mediática con HMM y Monte Carlo
===========================================================
Versión 4.0 — con solver de control óptimo y figura corregida
===========================================================
Cambios respecto a v3.0:
  - Nueva función `resolver_control_optimo` que resuelve el OCP del
    Teorema 5.2 usando scipy.optimize.minimize.
  - `generar_figuras` modifica la transición correcta
    (A[0, estado_verificador]) para la figura de sensibilidad.
  - `main` reporta la solución óptima del OCP.
  - Docstrings actualizados.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from hmmlearn import hmm
from pathlib import Path
from scipy.optimize import minimize
import sys
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

# ============================================================
# Configuración global
# ============================================================
ARCHIVO_ENTRADA = "datos_entrada.csv"
ARCHIVO_SALIDA = "resultados.csv"
ARCHIVO_ESTADOS = "estados_inferidos.csv"
ARCHIVO_MATRICES_LATEX = "matrices_latex.txt"
ARCHIVO_OCP = "control_optimo.txt"
CARPETA_FIGURAS = Path("figuras")
CARPETA_FIGURAS.mkdir(exist_ok=True)

SEMILLA_GLOBAL = 42
np.random.seed(SEMILLA_GLOBAL)

UMBRAL_BAJO = 3
UMBRAL_MEDIO = 6

N_ESTUDIANTES_MC = 100_000
N_SEMANAS_MC = 10
SEMANA_INTERVENCION = 5
MAX_PASOS_MC = 10_000

N_INIT_HMM = 10
N_ITER_HMM = 200
TOL_HMM = 1e-4

TOL_ESTOCASTICIDAD = 1e-8
TOL_PROB_CERO = 1e-10
TOL_NORMA_CERO = 1e-12


# ============================================================
# 0. Utilidades
# ============================================================
def verificar_estocasticidad(M, nombre="matriz", tol=TOL_ESTOCASTICIDAD):
    M = np.asarray(M, dtype=float)
    if M.ndim != 2 or M.shape[0] != M.shape[1]:
        raise ValueError(f"{nombre}: no es cuadrada ({M.shape})")
    if np.any(M < -tol):
        raise ValueError(f"{nombre}: contiene entradas negativas")
    sumas = M.sum(axis=1)
    if not np.allclose(sumas, 1.0, atol=tol):
        raise ValueError(f"{nombre}: las filas no suman 1 ({sumas})")
    return True


def imprimir_matriz_latex(M, nombre="A", decimales=4):
    M = np.asarray(M, dtype=float)
    filas, cols = M.shape
    lineas = [r"\begin{pmatrix}"]
    for i in range(filas):
        entradas = " & ".join(f"{M[i, j]:.{decimales}f}" for j in range(cols))
        lineas.append(f"    {entradas}" + (r" \\" if i < filas - 1 else ""))
    lineas.append(r"\end{pmatrix}")
    return f"% {nombre} =\n" + "\n".join(lineas)


def elegir_estado_verificador(modelo):
    medias = modelo.emissionprob_ @ np.array([0, 1, 2])
    return int(np.argmax(medias)), medias


# ============================================================
# 1. Leer datos
# ============================================================
def leer_datos(ruta):
    print(f"\n[1] Leyendo datos de {ruta}...")
    if not Path(ruta).exists():
        raise FileNotFoundError(f"No se encontró {ruta}")
    df = pd.read_csv(ruta)
    requeridas = {"estudiante_id", "semana", "aciertos",
                  "tiempo_decision", "compartida"}
    faltantes = requeridas - set(df.columns)
    if faltantes:
        raise ValueError(f"Faltan columnas: {faltantes}")
    if df["aciertos"].min() < 0 or df["aciertos"].max() > 10:
        raise ValueError("La columna 'aciertos' debe estar en [0, 10]")
    dup = df.duplicated(subset=["estudiante_id", "semana"]).sum()
    if dup > 0:
        raise ValueError(f"Hay {dup} filas duplicadas (estudiante-semana)")
    print(f"    Registros: {len(df)}")
    print(f"    Estudiantes: {df['estudiante_id'].nunique()}")
    print(f"    Semanas: {df['semana'].nunique()}")
    return df


# ============================================================
# 2. Discretizar
# ============================================================
def discretizar_observaciones(df, umbral_bajo=UMBRAL_BAJO,
                              umbral_medio=UMBRAL_MEDIO):
    print("\n[2] Discretizando observaciones...")
    if umbral_bajo >= umbral_medio:
        raise ValueError("umbral_bajo debe ser < umbral_medio")

    def categoria(aciertos):
        if aciertos <= umbral_bajo:
            return 0
        elif aciertos <= umbral_medio:
            return 1
        else:
            return 2

    df = df.copy()
    df["observacion"] = df["aciertos"].apply(categoria)
    for cat, nombre in enumerate(["bajo (0-3)", "medio (4-6)", "alto (7-10)"]):
        n = (df["observacion"] == cat).sum()
        print(f"      {nombre}: {n} ({100*n/len(df):.1f}%)")
    return df


# ============================================================
# 3. Ajustar HMM
# ============================================================
def ajustar_hmm(df, n_estados=3, n_init=N_INIT_HMM,
                n_iter=N_ITER_HMM, tol=TOL_HMM):
    print(f"\n[3] Ajustando HMM de {n_estados} estados "
          f"({n_init} reinicializaciones)...")
    secuencias = []
    longitudes = []
    for est_id, grupo in df.groupby("estudiante_id"):
        grupo = grupo.sort_values("semana")
        secuencias.append(grupo["observacion"].values)
        longitudes.append(len(grupo))
    X = np.concatenate(secuencias).reshape(-1, 1)
    lengths = longitudes

    mejores_modelos = []
    info_inits = []
    for i in range(n_init):
        modelo = hmm.CategoricalHMM(
            n_components=n_estados, n_iter=n_iter, tol=tol,
            random_state=SEMILLA_GLOBAL + i,
            init_params="ste", params="ste"
        )
        try:
            modelo.fit(X, lengths)
            ll = modelo.monitor_.history[-1]
            mejores_modelos.append((ll, modelo))
            info_inits.append({
                "init": i, "log_likelihood": ll,
                "converged": modelo.monitor_.converged,
                "n_iter": len(modelo.monitor_.history)
            })
        except Exception as e:
            print(f"    Init {i}: falló ({e})")
            info_inits.append({"init": i, "log_likelihood": np.nan,
                                "converged": False, "n_iter": 0})

    if not mejores_modelos:
        raise RuntimeError("Ninguna reinicialización convergió.")

    mejores_modelos.sort(key=lambda x: x[0], reverse=True)
    ll_mejor, modelo = mejores_modelos[0]
    info_inits = pd.DataFrame(info_inits)
    print(f"\n    Mejor log-verosimilitud: {ll_mejor:.4f}")
    print(f"    Convergentes: {info_inits['converged'].sum()}/{n_init}")
    verificar_estocasticidad(modelo.transmat_, "A estimada")
    verificar_estocasticidad(modelo.emissionprob_, "B estimada")
    print(f"\n    Matriz A:\n    {modelo.transmat_}")
    print(f"\n    Matriz B:\n    {modelo.emissionprob_}")
    return modelo, secuencias, lengths, info_inits


# ============================================================
# 4. Inferir estados
# ============================================================
def inferir_estados(modelo, secuencias, lengths):
    print("\n[4] Infiriendo estados ocultos con Viterbi...")
    estados_por_estudiante = []
    for i in range(len(lengths)):
        sec = secuencias[i].reshape(-1, 1)
        _, estados = modelo.decode(sec, algorithm="viterbi")
        estados_por_estudiante.append(estados)

    _, medias = elegir_estado_verificador(modelo)
    orden = np.argsort(medias)
    print(f"    Medias de emisión: {medias}")
    print(f"    Orden: {orden}")

    estados_reetiquetados = []
    for estados in estados_por_estudiante:
        nuevo = np.zeros_like(estados)
        for viejo, nuevo_idx in enumerate(orden):
            nuevo[estados == viejo] = nuevo_idx
        estados_reetiquetados.append(nuevo)
    return estados_reetiquetados


# ============================================================
# 5. Distribución estacionaria y tiempo de retorno
# ============================================================
def calcular_distribucion_estacionaria(A, tol=TOL_PROB_CERO):
    A = np.asarray(A, dtype=float)
    verificar_estocasticidad(A, "A en calcular_distribucion_estacionaria")
    n = A.shape[0]
    M = np.linalg.matrix_power(np.eye(n) + A, n - 1)
    if np.any(M <= 0):
        raise ValueError("La matriz A no es irreducible (no ergódica).")
    vals, vecs = np.linalg.eig(A.T)
    idx = np.argmin(np.abs(vals - 1.0))
    pi = np.real(vecs[:, idx])
    if pi.sum() < 0:
        pi = -pi
    pi = np.maximum(pi, 0.0)
    suma = pi.sum()
    if suma < tol:
        raise ValueError("No se pudo normalizar π.")
    return pi / suma


def calcular_tiempo_retorno(A, estado_objetivo, tol=TOL_PROB_CERO):
    pi = calcular_distribucion_estacionaria(A, tol=tol)
    if pi[estado_objetivo] < tol:
        raise ValueError(
            f"π_{estado_objetivo}* ≈ 0; estado transitorio/absorbente.")
    return 1.0 / pi[estado_objetivo], pi


def verificar_teorema_retorno(modelo, n_simulaciones=100_000,
                               max_pasos=MAX_PASOS_MC):
    print("\n[5] Verificando Teorema 4.1 (mean return time)...")
    estado_verificador, medias = elegir_estado_verificador(modelo)
    print(f"    Estado verificador: {estado_verificador} "
          f"(media = {medias[estado_verificador]:.4f})")
    E_teorico, pi = calcular_tiempo_retorno(
        modelo.transmat_, estado_objetivo=estado_verificador)
    print(f"    π* = {pi}")
    print(f"    E_{estado_verificador}[T_{estado_verificador}] "
          f"teórico = {E_teorico:.6f}")

    A = modelo.transmat_
    rng = np.random.default_rng(SEMILLA_GLOBAL)
    tiempos = np.zeros(n_simulaciones, dtype=int)
    truncados = 0
    for i in range(n_simulaciones):
        estado = estado_verificador
        estado = rng.choice(A.shape[0], p=A[estado])
        t = 1
        while estado != estado_verificador and t < max_pasos:
            estado = rng.choice(A.shape[0], p=A[estado])
            t += 1
        if t >= max_pasos:
            truncados += 1
        tiempos[i] = t

    E_empirico = tiempos.mean()
    SE = tiempos.std(ddof=1) / np.sqrt(n_simulaciones)
    print(f"    E_{estado_verificador}[T_{estado_verificador}] "
          f"empírico = {E_empirico:.6f} ± {SE:.6f}")
    if truncados > 0:
        print(f"    ADVERTENCIA: {truncados} trayectorias truncadas.")
    dif_rel = 100 * abs(E_empirico - E_teorico) / E_teorico
    print(f"    Diferencia relativa: {dif_rel:.2f}%")
    return E_teorico, E_empirico, SE


# ============================================================
# 5b. SOLVER DE CONTROL ÓPTIMO (Teorema 5.2)
# ============================================================
def resolver_control_optimo(modelo, epsilon=0.5, verbose=True):
    """
    Resuelve el problema de control óptimo del Teorema 5.2:

        min_{I ∈ I_ε}  E_3[T_3(I)]
        s.t.  A' = I A_0
              I fila-estocástica
              ||I - I_0||_1 <= ε

    Usa scipy.optimize.minimize con SLSQP.

    Parametrización: I se representa como 9 variables libres, que se
    proyectan a la variedad de matrices fila-estocásticas normalizando
    cada fila. La restricción ||I - I_0||_1 <= ε se impone como
    restricción de desigualdad.

    Retorna
    -------
    I_opt : array (3, 3)
        Matriz de intervención óptima.
    info : dict
        Información del solver (éxito, iteraciones, valor óptimo).
    """
    if verbose:
        print("\n[5b] Resolviendo el problema de control óptimo (Teorema 5.2)...")

    A0 = modelo.transmat_.copy()
    estado_verificador, _ = elegir_estado_verificador(modelo)
    n = A0.shape[0]
    I0 = np.eye(n)

    def vector_a_matriz_estocastica(x):
        """Convierte un vector de 9 entradas en una matriz fila-estocástica."""
        M = x.reshape(n, n)
        M = np.maximum(M, 0.0)  # proyectar a no negativo
        sumas = M.sum(axis=1, keepdims=True)
        sumas = np.where(sumas < 1e-12, 1.0, sumas)
        return M / sumas

    def objetivo(x):
        """E_3[T_3(I)] = 1/π_3*(I A_0)."""
        I = vector_a_matriz_estocastica(x)
        A_prima = I @ A0
        # Asegurar estocasticidad
        A_prima = np.maximum(A_prima, 0.0)
        A_prima = A_prima / A_prima.sum(axis=1, keepdims=True)
        try:
            E, _ = calcular_tiempo_retorno(A_prima, estado_verificador)
        except ValueError:
            return 1e6  # penalización
        return E

    def restriccion_epsilon(x):
        """||I - I_0||_1 <= epsilon  →  epsilon - ||I - I_0||_1 >= 0."""
        I = vector_a_matriz_estocastica(x)
        return epsilon - np.sum(np.abs(I - I0))

    # Punto inicial: identidad
    x0 = I0.flatten().copy()

    # Restricciones
    restricciones = [{"type": "ineq", "fun": restriccion_epsilon}]

    # Optimización
    resultado = minimize(
        objetivo, x0,
        method="SLSQP",
        constraints=restricciones,
        options={"maxiter": 500, "ftol": 1e-8, "disp": False}
    )

    I_opt = vector_a_matriz_estocastica(resultado.x)
    E_opt = objetivo(resultado.x)
    E_base, _ = calcular_tiempo_retorno(A0, estado_verificador)

    if verbose:
        print(f"    Éxito: {resultado.success}")
        print(f"    Iteraciones: {resultado.nit}")
        print(f"    ||I_opt - I_0||_1 = {np.sum(np.abs(I_opt - I0)):.6f} "
              f"(ε = {epsilon})")
        print(f"    E[T_3] base    = {E_base:.6f}")
        print(f"    E[T_3] óptimo  = {E_opt:.6f}")
        reduccion = 100 * (E_base - E_opt) / E_base
        print(f"    Reducción      = {reduccion:.2f}%")
        print(f"    Matriz I_opt:\n{I_opt}")

    info = {
        "success": resultado.success,
        "nit": resultado.nit,
        "E_base": E_base,
        "E_opt": E_opt,
        "reduccion_pct": 100 * (E_base - E_opt) / E_base,
        "epsilon": epsilon,
        "norma_I_menos_I0": np.sum(np.abs(I_opt - I0)),
        "estado_verificador": estado_verificador,
    }
    return I_opt, info


def simular_con_intervencion_optima(modelo, I_opt,
                                     n_estudiantes=N_ESTUDIANTES_MC,
                                     n_semanas=N_SEMANAS_MC,
                                     semilla=SEMILLA_GLOBAL):
    """Simula Monte Carlo con la intervención óptima I_opt aplicada en t=0."""
    A0 = modelo.transmat_.copy()
    pi = modelo.startprob_.copy()
    A_prima = I_opt @ A0
    A_prima = np.maximum(A_prima, 0.0)
    A_prima = A_prima / A_prima.sum(axis=1, keepdims=True)
    estado_verificador, _ = elegir_estado_verificador(modelo)

    rng = np.random.default_rng(semilla)
    estados_finales = np.zeros(n_estudiantes, dtype=int)
    for i in range(n_estudiantes):
        estado = rng.choice(A0.shape[0], p=pi)
        for t in range(n_semanas):
            estado = rng.choice(A_prima.shape[0], p=A_prima[estado])
        estados_finales[i] = estado

    p = (estados_finales == estado_verificador).mean()
    SE = np.sqrt(p * (1 - p) / n_estudiantes)
    return {"p_verificador": p, "error_estandar": SE,
            "ic_inferior": p - 1.96 * SE, "ic_superior": p + 1.96 * SE}


# ============================================================
# 6. Monte Carlo con intervención en t=5
# ============================================================
def construir_matriz_intervencion(A_base, escenario):
    A = np.asarray(A_base, dtype=float).copy()
    if escenario == "tutoria":
        A[0, 1] *= 1.5
        A[1, 2] *= 1.5
    elif escenario == "gamificacion":
        A[0, 2] *= 2.0
    elif escenario != "sin_intervencion":
        raise ValueError(f"Escenario desconocido: {escenario}")
    A = A / A.sum(axis=1, keepdims=True)
    verificar_estocasticidad(A, f"A_{escenario}")
    return A


def simular_monte_carlo(modelo, n_estudiantes=N_ESTUDIANTES_MC,
                        n_semanas=N_SEMANAS_MC,
                        semana_intervencion=SEMANA_INTERVENCION,
                        escenario="sin_intervencion",
                        semilla=SEMILLA_GLOBAL):
    A_base = modelo.transmat_.copy()
    pi = modelo.startprob_.copy()
    A_intervenida = construir_matriz_intervencion(A_base, escenario)
    estado_verificador, _ = elegir_estado_verificador(modelo)

    rng = np.random.default_rng(semilla)
    estados_finales = np.zeros(n_estudiantes, dtype=int)
    for i in range(n_estudiantes):
        estado = rng.choice(A_base.shape[0], p=pi)
        for t in range(n_semanas):
            A_actual = A_intervenida if t >= semana_intervencion else A_base
            estado = rng.choice(A_actual.shape[0], p=A_actual[estado])
        estados_finales[i] = estado

    p = (estados_finales == estado_verificador).mean()
    SE = np.sqrt(p * (1 - p) / n_estudiantes)
    return {"escenario": escenario, "p_verificador": p,
            "error_estandar": SE,
            "ic_inferior": p - 1.96 * SE,
            "ic_superior": p + 1.96 * SE,
            "estados_finales": estados_finales}


# ============================================================
# 7. Cota de gamificación
# ============================================================
def verificar_cota_gamificacion(a13=0.2, alpha=1.5, T=5,
                                 n_simulaciones=200_000,
                                 semilla=SEMILLA_GLOBAL):
    print("\n[7] Verificando Corolario 6.1 (cota de gamificación)...")
    if alpha * a13 > 1:
        raise ValueError("α·a13 debe ser ≤ 1")
    cota = 1 - (1 - alpha * a13) ** T
    print(f"    Cota teórica: {cota:.5f}")

    rng = np.random.default_rng(semilla)
    exitos = 0
    for _ in range(n_simulaciones):
        for t in range(T):
            if rng.random() < alpha * a13:
                exitos += 1
                break
    p = exitos / n_simulaciones
    SE = np.sqrt(p * (1 - p) / n_simulaciones)
    print(f"    P(empírica): {p:.5f} ± {SE:.5f}")
    print(f"    ¿Se cumple? {'SÍ' if p >= cota - 1e-2 else 'NO'}")
    return cota, p


# ============================================================
# 8. Comparación con BioPython
# ============================================================
def calcular_similitud_biopython(vectores, tol_norma=TOL_NORMA_CERO):
    X = np.asarray(vectores, dtype=float)
    if X.ndim != 2:
        raise ValueError("'vectores' debe ser una matriz 2D (n, d)")
    n = X.shape[0]
    medias = X.mean(axis=0)
    desv = X.std(axis=0)
    desv_segura = np.where(desv < tol_norma, 1.0, desv)
    Xz = (X - medias) / desv_segura
    normas = np.linalg.norm(Xz, axis=1)
    S = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(n):
            ni, nj = normas[i], normas[j]
            if ni < tol_norma and nj < tol_norma:
                S[i, j] = 1.0 if np.allclose(X[i], X[j],
                                              atol=tol_norma) else 0.0
            elif ni < tol_norma or nj < tol_norma:
                S[i, j] = 0.0
            else:
                cos = float(np.dot(Xz[i], Xz[j]) / (ni * nj))
                cos = max(-1.0, min(1.0, cos))
                S[i, j] = (1.0 + cos) / 2.0
    np.fill_diagonal(S, 1.0)
    return S


def comparar_con_biopython(df):
    print("\n[8] Comparación con BioPython ProtParam (demo)...")
    df_est = df.groupby("estudiante_id")[
        ["aciertos", "tiempo_decision", "compartida"]].mean()
    S = calcular_similitud_biopython(df_est.values)
    assert np.allclose(np.diag(S), 1.0)
    assert np.all(S >= -1e-10) and np.all(S <= 1 + 1e-10)
    print(f"    Matriz de similitud (3x3):\n{S[:3, :3]}")
    return S


# ============================================================
# 9. Figuras
# ============================================================
def generar_figuras(estados_por_estudiante, modelo, df):
    print("\n[9] Generando figuras...")

    # --- Figura 1: Trayectorias ---
    fig, ax = plt.subplots(figsize=(8, 4))
    colores = ["#d62728", "#ff7f0e", "#2ca02c", "#1f77b4", "#9467bd"]
    nombres = ["Credulous", "Passive skeptic", "Active verifier"]
    for i in range(min(5, len(estados_por_estudiante))):
        estados = estados_por_estudiante[i]
        ax.plot(range(1, len(estados)+1), estados, "o-",
                color=colores[i], label=f"Student {i+1}",
                markersize=6, linewidth=1.5)
    ax.set_xlabel("Week")
    ax.set_ylabel("Hidden state")
    ax.set_yticks([0, 1, 2])
    ax.set_yticklabels(nombres)
    ax.legend(loc="center left", bbox_to_anchor=(1, 0.5))
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(CARPETA_FIGURAS / "trayectorias.pdf", dpi=300,
                bbox_inches="tight")
    plt.close()

    # --- Figura 2: Sensibilidad (corregida) ---
    # Se modifica A[0, estado_verificador] (transición del crédulo al
    # verificador), que es la transición que el Corolario 6.1 describe.
    fig, ax = plt.subplots(figsize=(6, 4))
    A_base = modelo.transmat_.copy()
    estado_verificador, _ = elegir_estado_verificador(modelo)
    # Encontrar el estado crédulo (menor media)
    _, medias = elegir_estado_verificador(modelo)
    estado_credulo = int(np.argmin(medias))

    tasas = np.linspace(0.05, 0.50, 12)
    probs, SEs = [], []
    n_sim = 100_000
    for tasa in tasas:
        A = A_base.copy()
        # Modificar la transición del crédulo al verificador
        A[estado_credulo, estado_verificador] = tasa
        # Renormalizar la fila del crédulo
        A[estado_credulo] = A[estado_credulo] / A[estado_credulo].sum()
        # Renormalizar todas las filas por seguridad
        A = A / A.sum(axis=1, keepdims=True)
        verificar_estocasticidad(A, f"A(tasa={tasa:.2f})")
        rng = np.random.default_rng(SEMILLA_GLOBAL)
        exitos = 0
        for _ in range(n_sim):
            estado = rng.choice(3, p=modelo.startprob_)
            for t in range(10):
                estado = rng.choice(3, p=A[estado])
            if estado == estado_verificador:
                exitos += 1
        p = exitos / n_sim
        probs.append(p)
        SEs.append(np.sqrt(p * (1 - p) / n_sim))
    probs = np.array(probs)
    SEs = np.array(SEs)
    ax.errorbar(tasas, probs, yerr=1.96*SEs, fmt="o-",
                color="#1f77b4", linewidth=2, capsize=3)
    ax.set_xlabel("Learning rate $a_{\\mathrm{cred,ver}}$")
    ax.set_ylabel("$\\mathbb{P}(s_{10} = s_3)$")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(CARPETA_FIGURAS / "sensibilidad.pdf", dpi=300,
                bbox_inches="tight")
    plt.close()

    print(f"    Figuras guardadas en {CARPETA_FIGURAS}/")


# ============================================================
# 10. Guardar resultados
# ============================================================
def guardar_resultados(df, estados_por_estudiante, resultados_mc,
                       modelo, info_inits, I_opt, info_ocp):
    print(f"\n[10] Guardando resultados...")

    df_mc = pd.DataFrame([{
        "escenario": r["escenario"],
        "p_verificador": r["p_verificador"],
        "error_estandar": r["error_estandar"],
        "ic_inferior": r["ic_inferior"],
        "ic_superior": r["ic_superior"]
    } for r in resultados_mc])
    df_mc.to_csv(ARCHIVO_SALIDA, index=False)

    df_estados = []
    idx = 0
    for est_id, grupo in df.groupby("estudiante_id"):
        grupo = grupo.sort_values("semana")
        estados = estados_por_estudiante[idx]
        for semana, estado in zip(grupo["semana"].values, estados):
            df_estados.append({"estudiante_id": est_id,
                                "semana": semana,
                                "estado_inferido": int(estado)})
        idx += 1
    pd.DataFrame(df_estados).to_csv(ARCHIVO_ESTADOS, index=False)

    with open(ARCHIVO_MATRICES_LATEX, "w") as f:
        f.write("% Matrices estimadas por el HMM\n")
        f.write(imprimir_matriz_latex(modelo.transmat_, "A") + "\n\n")
        f.write(imprimir_matriz_latex(modelo.emissionprob_, "B") + "\n\n")
        f.write("% Distribución inicial\n")
        f.write("\\pi = (" +
                ", ".join(f"{p:.4f}" for p in modelo.startprob_) + ")\n\n")
        f.write("% Resultados de las reinicializaciones\n")
        f.write(info_inits.to_string(index=False))

    with open(ARCHIVO_OCP, "w") as f:
        f.write("SOLUCIÓN DEL PROBLEMA DE CONTROL ÓPTIMO\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Estado verificador: {info_ocp['estado_verificador']}\n")
        f.write(f"epsilon: {info_ocp['epsilon']}\n")
        f.write(f"Éxito del solver: {info_ocp['success']}\n")
        f.write(f"Iteraciones: {info_ocp['nit']}\n")
        f.write(f"||I_opt - I_0||_1: {info_ocp['norma_I_menos_I0']:.6f}\n")
        f.write(f"E[T_3] base: {info_ocp['E_base']:.6f}\n")
        f.write(f"E[T_3] óptimo: {info_ocp['E_opt']:.6f}\n")
        f.write(f"Reducción: {info_ocp['reduccion_pct']:.2f}%\n\n")
        f.write("Matriz I_opt:\n")
        f.write(np.array2string(I_opt, precision=4, suppress_small=True))

    print(f"    {ARCHIVO_SALIDA}")
    print(f"    {ARCHIVO_ESTADOS}")
    print(f"    {ARCHIVO_MATRICES_LATEX}")
    print(f"    {ARCHIVO_OCP}")


# ============================================================
# 11. Main
# ============================================================
def main():
    print("=" * 70)
    print("MODELADO DE ALFABETIZACIÓN MEDIÁTICA CON HMM Y MONTE CARLO")
    print("Versión 4.0 — con solver de control óptimo")
    print("=" * 70)

    try:
        df = leer_datos(ARCHIVO_ENTRADA)
    except (FileNotFoundError, ValueError) as e:
        print(f"\nERROR: {e}")
        sys.exit(1)

    df = discretizar_observaciones(df)
    modelo, secuencias, lengths, info_inits = ajustar_hmm(df, n_estados=3)
    estados = inferir_estados(modelo, secuencias, lengths)

    E_teo, E_emp, SE_emp = verificar_teorema_retorno(modelo)

    # --- NUEVO: resolver el OCP ---
    I_opt, info_ocp = resolver_control_optimo(modelo, epsilon=0.5)

    # --- NUEVO: simular con la intervención óptima ---
    print("\n[6b] Simulando con la intervención óptima...")
    r_opt = simular_con_intervencion_optima(modelo, I_opt)
    print(f"    P(verificador | I_opt) = "
          f"{r_opt['p_verificador']:.4f} ± {r_opt['error_estandar']:.4f}")

    print("\n[6] Simulación de Monte Carlo...")
    resultados_mc = []
    for escenario in ["sin_intervencion", "tutoria", "gamificacion"]:
        r = simular_monte_carlo(modelo, escenario=escenario)
        resultados_mc.append(r)
        print(f"    {escenario:20s}: P(verificador) = "
              f"{r['p_verificador']:.4f} ± {r['error_estandar']:.4f}")

    verificar_cota_gamificacion()
    comparar_con_biopython(df)
    generar_figuras(estados, modelo, df)
    guardar_resultados(df, estados, resultados_mc, modelo, info_inits,
                       I_opt, info_ocp)

    print("\n" + "=" * 70)
    print("PROCESO COMPLETADO")
    print("=" * 70)


if __name__ == "__main__":
    main()
