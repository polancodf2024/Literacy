"""
Tests unitarios para alfabetizacion.py
=======================================
Versión alineada con alfabetizacion.py v4.0 (con solver de control óptimo).

Valores de referencia verificados a mano:
  - π*         = (9/41, 13/41, 19/41)
  - E_3[T_3]   = 41/19 ≈ 2.157895  (mean return time)
  - π*'        = (77/412, 115/412, 220/412)
  - E_3[T_3]'  = 103/55 ≈ 1.872727

Ejecutar con:
    pytest test_alfabetizacion.py -v
"""

import numpy as np
import pandas as pd
import pytest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))
from alfabetizacion import (
    verificar_estocasticidad,
    imprimir_matriz_latex,
    discretizar_observaciones,
    calcular_distribucion_estacionaria,
    calcular_tiempo_retorno,
    construir_matriz_intervencion,
    simular_monte_carlo,
    verificar_cota_gamificacion,
    calcular_similitud_biopython,
    elegir_estado_verificador,
    resolver_control_optimo,
    simular_con_intervencion_optima,
    TOL_PROB_CERO,
    TOL_NORMA_CERO,
)

try:
    import hmmlearn
    HMMLEARN_DISPONIBLE = True
except ImportError:
    HMMLEARN_DISPONIBLE = False


# ============================================================
# Fixtures
# ============================================================
@pytest.fixture
def matriz_A_ejemplo_7_1():
    """Matriz del Ejemplo 7.1 del manuscrito, en fracciones exactas."""
    return np.array([
        [1/2, 3/10, 1/5],
        [1/5, 1/2, 3/10],
        [1/10, 1/5, 7/10]
    ])


@pytest.fixture
def matriz_A_prime_ejemplo_7_5():
    """Matriz modificada del Ejemplo 7.5, en fracciones exactas."""
    return np.array([
        [5/11, 3/11, 3/11],
        [4/23, 10/23, 9/23],
        [1/10, 1/5, 7/10]
    ])


@pytest.fixture
def df_sintetico_10x10():
    rng = np.random.default_rng(42)
    filas = []
    for est in range(1, 11):
        for sem in range(1, 11):
            filas.append({
                "estudiante_id": f"E{est:03d}",
                "semana": sem,
                "aciertos": int(rng.integers(0, 11)),
                "tiempo_decision": float(rng.uniform(1, 10)),
                "compartida": int(rng.integers(0, 2))
            })
    return pd.DataFrame(filas)


@pytest.fixture
def df_tres_categorias():
    return pd.DataFrame({
        "estudiante_id": ["E1"] * 9,
        "semana": list(range(1, 10)),
        "aciertos": [1, 2, 3, 4, 5, 6, 7, 8, 9],
        "tiempo_decision": [5.0] * 9,
        "compartida": [0, 1, 0, 1, 0, 1, 0, 1, 0]
    })


@pytest.fixture
def modelo_hmm_falso(matriz_A_ejemplo_7_1):
    class ModeloFalso:
        pass
    m = ModeloFalso()
    m.transmat_ = matriz_A_ejemplo_7_1
    m.emissionprob_ = np.array([[0.7, 0.2, 0.1],
                                 [0.2, 0.6, 0.2],
                                 [0.1, 0.3, 0.6]])
    m.startprob_ = np.array([0.33, 0.34, 0.33])
    return m


# ============================================================
# Tests: verificar_estocasticidad
# ============================================================
class TestVerificarEstocasticidad:

    def test_matriz_valida(self, matriz_A_ejemplo_7_1):
        assert verificar_estocasticidad(matriz_A_ejemplo_7_1) is True

    def test_matriz_identidad(self):
        assert verificar_estocasticidad(np.eye(3)) is True

    def test_filas_no_suman_uno(self):
        M = np.array([[0.5, 0.3, 0.1], [0.2, 0.5, 0.3], [0.1, 0.2, 0.7]])
        with pytest.raises(ValueError, match="no suman 1"):
            verificar_estocasticidad(M)

    def test_entradas_negativas(self):
        M = np.array([[1.1, -0.1, 0.0], [0.2, 0.5, 0.3], [0.1, 0.2, 0.7]])
        with pytest.raises(ValueError, match="negativas"):
            verificar_estocasticidad(M)

    def test_no_cuadrada(self):
        M = np.array([[0.5, 0.5], [0.3, 0.7], [0.1, 0.9]])
        with pytest.raises(ValueError, match="no es cuadrada"):
            verificar_estocasticidad(M)

    def test_acepta_lista(self):
        assert verificar_estocasticidad([[0.5, 0.5], [0.3, 0.7]]) is True


# ============================================================
# Tests: imprimir_matriz_latex
# ============================================================
class TestImprimirMatrizLatex:

    def test_contiene_pmatrix(self, matriz_A_ejemplo_7_1):
        s = imprimir_matriz_latex(matriz_A_ejemplo_7_1, "A")
        assert r"\begin{pmatrix}" in s and r"\end{pmatrix}" in s

    def test_contiene_nombre(self, matriz_A_ejemplo_7_1):
        assert "A_test" in imprimir_matriz_latex(matriz_A_ejemplo_7_1,
                                                   "A_test")

    def test_numero_decimales(self, matriz_A_ejemplo_7_1):
        s = imprimir_matriz_latex(matriz_A_ejemplo_7_1, "A", decimales=2)
        assert "0.50" in s and "0.5000" not in s


# ============================================================
# Tests: discretizar_observaciones
# ============================================================
class TestDiscretizarObservaciones:

    def test_tres_categorias(self, df_tres_categorias):
        df_out = discretizar_observaciones(df_tres_categorias)
        assert df_out["observacion"].nunique() == 3

    def test_umbrales_correctos(self, df_tres_categorias):
        df_out = discretizar_observaciones(df_tres_categorias)
        obs = df_out.sort_values("semana")["observacion"].values
        assert list(obs) == [0, 0, 0, 1, 1, 1, 2, 2, 2]

    def test_umbrales_invalidos(self, df_tres_categorias):
        with pytest.raises(ValueError, match="umbral_bajo"):
            discretizar_observaciones(df_tres_categorias,
                                      umbral_bajo=6, umbral_medio=3)

    def test_no_modifica_original(self, df_tres_categorias):
        df_original = df_tres_categorias.copy()
        _ = discretizar_observaciones(df_tres_categorias)
        pd.testing.assert_frame_equal(df_tres_categorias, df_original)


# ============================================================
# Tests: calcular_distribucion_estacionaria
# ============================================================
class TestDistribucionEstacionaria:

    def test_ejemplo_7_1(self, matriz_A_ejemplo_7_1):
        """π* = (9/41, 13/41, 19/41)."""
        pi = calcular_distribucion_estacionaria(matriz_A_ejemplo_7_1)
        assert abs(pi[0] - 9/41) < 1e-6
        assert abs(pi[1] - 13/41) < 1e-6
        assert abs(pi[2] - 19/41) < 1e-6

    def test_ejemplo_7_5(self, matriz_A_prime_ejemplo_7_5):
        """π*' = (77/412, 115/412, 220/412)."""
        pi = calcular_distribucion_estacionaria(matriz_A_prime_ejemplo_7_5)
        assert abs(pi[0] - 77/412) < 1e-6
        assert abs(pi[1] - 115/412) < 1e-6
        assert abs(pi[2] - 220/412) < 1e-6

    def test_pi_suma_uno(self, matriz_A_ejemplo_7_1):
        pi = calcular_distribucion_estacionaria(matriz_A_ejemplo_7_1)
        assert abs(pi.sum() - 1.0) < 1e-10

    def test_pi_positiva(self, matriz_A_ejemplo_7_1):
        pi = calcular_distribucion_estacionaria(matriz_A_ejemplo_7_1)
        assert np.all(pi > 0)

    def test_pi_satisface_balance(self, matriz_A_ejemplo_7_1):
        pi = calcular_distribucion_estacionaria(matriz_A_ejemplo_7_1)
        np.testing.assert_array_almost_equal(pi @ matriz_A_ejemplo_7_1, pi,
                                              decimal=10)

    def test_matriz_no_ergodica(self):
        A = np.array([[1.0, 0.0, 0.0],
                      [0.0, 0.5, 0.5],
                      [0.0, 0.5, 0.5]])
        with pytest.raises(ValueError):
            calcular_distribucion_estacionaria(A)

    def test_matriz_invalida(self):
        M = np.array([[0.5, 0.3, 0.1], [0.2, 0.5, 0.3], [0.1, 0.2, 0.7]])
        with pytest.raises(ValueError):
            calcular_distribucion_estacionaria(M)


# ============================================================
# Tests: calcular_tiempo_retorno (Teorema 4.1)
# ============================================================
class TestTiempoRetorno:

    def test_valor_teorico_ejemplo_7_1(self, matriz_A_ejemplo_7_1):
        """
        Para la matriz del Ejemplo 7.1:
          π* = (9/41, 13/41, 19/41)
          E_3[T_3] = 1/π_3* = 41/19 ≈ 2.157895  (mean return time)
        """
        E, pi = calcular_tiempo_retorno(matriz_A_ejemplo_7_1,
                                          estado_objetivo=2)
        assert abs(E - 41/19) < 1e-6
        assert abs(pi[2] - 19/41) < 1e-6

    def test_valor_teorico_ejemplo_7_5(self, matriz_A_prime_ejemplo_7_5):
        """
        Para la matriz del Ejemplo 7.5:
          π*' = (77/412, 115/412, 220/412)
          E_3[T_3]' = 1/π_3*' = 103/55 ≈ 1.872727
        """
        E, pi = calcular_tiempo_retorno(matriz_A_prime_ejemplo_7_5,
                                          estado_objetivo=2)
        assert abs(E - 103/55) < 1e-6
        assert abs(pi[2] - 220/412) < 1e-6

    def test_tiempo_retorno_mayor_que_uno(self, matriz_A_ejemplo_7_1):
        E, _ = calcular_tiempo_retorno(matriz_A_ejemplo_7_1,
                                        estado_objetivo=2)
        assert E > 1

    def test_estado_transitorio(self):
        A = np.array([[1.0, 0.0, 0.0],
                      [0.0, 0.5, 0.5],
                      [0.0, 0.5, 0.5]])
        with pytest.raises(ValueError):
            calcular_tiempo_retorno(A, estado_objetivo=1)


# ============================================================
# Tests: elegir_estado_verificador
# ============================================================
class TestElegirEstadoVerificador:

    def test_elige_mayor_media(self, modelo_hmm_falso):
        estado, medias = elegir_estado_verificador(modelo_hmm_falso)
        assert estado == int(np.argmax(medias))
        assert medias[estado] == max(medias)

    def test_estado_en_rango(self, modelo_hmm_falso):
        estado, _ = elegir_estado_verificador(modelo_hmm_falso)
        assert 0 <= estado < 3


# ============================================================
# Tests: construir_matriz_intervencion
# ============================================================
class TestConstruirMatrizIntervencion:

    def test_sin_intervencion(self, matriz_A_ejemplo_7_1):
        A = construir_matriz_intervencion(matriz_A_ejemplo_7_1,
                                          "sin_intervencion")
        np.testing.assert_array_almost_equal(A, matriz_A_ejemplo_7_1)

    def test_tutoria_estocastica(self, matriz_A_ejemplo_7_1):
        verificar_estocasticidad(
            construir_matriz_intervencion(matriz_A_ejemplo_7_1, "tutoria"),
            "tutoria")

    def test_gamificacion_estocastica(self, matriz_A_ejemplo_7_1):
        verificar_estocasticidad(
            construir_matriz_intervencion(matriz_A_ejemplo_7_1,
                                            "gamificacion"),
            "gamificacion")

    def test_tutoria_aumenta_a01(self, matriz_A_ejemplo_7_1):
        A = construir_matriz_intervencion(matriz_A_ejemplo_7_1, "tutoria")
        assert A[0, 1] > matriz_A_ejemplo_7_1[0, 1]

    def test_gamificacion_aumenta_a02(self, matriz_A_ejemplo_7_1):
        A = construir_matriz_intervencion(matriz_A_ejemplo_7_1,
                                            "gamificacion")
        assert A[0, 2] > matriz_A_ejemplo_7_1[0, 2]

    def test_escenario_invalido(self, matriz_A_ejemplo_7_1):
        with pytest.raises(ValueError, match="Escenario desconocido"):
            construir_matriz_intervencion(matriz_A_ejemplo_7_1, "magia")

    def test_no_modifica_original(self, matriz_A_ejemplo_7_1):
        A_orig = matriz_A_ejemplo_7_1.copy()
        _ = construir_matriz_intervencion(matriz_A_ejemplo_7_1, "tutoria")
        np.testing.assert_array_almost_equal(matriz_A_ejemplo_7_1, A_orig)


# ============================================================
# Tests: simular_monte_carlo
# ============================================================
class TestSimularMonteCarlo:

    def test_resultado_estructura(self, modelo_hmm_falso):
        r = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=1000,
                                n_semanas=5, semilla=42)
        assert "p_verificador" in r and "error_estandar" in r
        assert r["escenario"] == "sin_intervencion"

    def test_probabilidad_en_rango(self, modelo_hmm_falso):
        r = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=10_000,
                                n_semanas=10, semilla=42)
        assert 0.0 <= r["p_verificador"] <= 1.0

    def test_ic_contiene_p(self, modelo_hmm_falso):
        r = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=10_000,
                                n_semanas=10, semilla=42)
        assert r["ic_inferior"] <= r["p_verificador"] <= r["ic_superior"]

    def test_reproducibilidad(self, modelo_hmm_falso):
        r1 = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=5000,
                                 n_semanas=10, semilla=123)
        r2 = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=5000,
                                 n_semanas=10, semilla=123)
        assert r1["p_verificador"] == r2["p_verificador"]

    def test_gamificacion_mayor_que_sin_intervencion(self, modelo_hmm_falso):
        r_sin = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=20_000,
                                    n_semanas=10,
                                    escenario="sin_intervencion", semilla=42)
        r_gam = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=20_000,
                                    n_semanas=10,
                                    escenario="gamificacion", semilla=42)
        assert r_gam["p_verificador"] > r_sin["p_verificador"]

    def test_intervencion_en_semana_5(self, modelo_hmm_falso):
        r_sin = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=20_000,
                                    n_semanas=4,
                                    escenario="sin_intervencion",
                                    semana_intervencion=5, semilla=42)
        r_gam = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=20_000,
                                    n_semanas=4,
                                    escenario="gamificacion",
                                    semana_intervencion=5, semilla=42)
        assert abs(r_sin["p_verificador"] - r_gam["p_verificador"]) < 1e-10

    def test_intervencion_activa_despues_semana_5(self, modelo_hmm_falso):
        r_sin = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=50_000,
                                    n_semanas=10,
                                    escenario="sin_intervencion",
                                    semana_intervencion=5, semilla=42)
        r_gam = simular_monte_carlo(modelo_hmm_falso, n_estudiantes=50_000,
                                    n_semanas=10,
                                    escenario="gamificacion",
                                    semana_intervencion=5, semilla=42)
        assert r_gam["p_verificador"] > r_sin["p_verificador"]


# ============================================================
# Tests: verificar_cota_gamificacion (Corolario 6.1)
# ============================================================
class TestCotaGamificacion:

    def test_cota_teorica_ejemplo(self):
        cota, _ = verificar_cota_gamificacion(
            a13=0.2, alpha=1.5, T=5, n_simulaciones=10_000
        )
        assert abs(cota - 0.83193) < 1e-5

    def test_cota_se_cumple(self):
        cota, p = verificar_cota_gamificacion(
            a13=0.2, alpha=1.5, T=5, n_simulaciones=200_000
        )
        assert p >= cota - 1e-2

    def test_alpha_invalido(self):
        with pytest.raises(ValueError, match="α·a13"):
            verificar_cota_gamificacion(a13=0.9, alpha=2.0, T=5)

    def test_T_cero(self):
        cota, p = verificar_cota_gamificacion(
            a13=0.2, alpha=1.5, T=0, n_simulaciones=1000
        )
        assert cota == 0.0 and p == 0.0

    def test_reproducibilidad(self):
        _, p1 = verificar_cota_gamificacion(
            a13=0.2, alpha=1.5, T=5, n_simulaciones=5000, semilla=123
        )
        _, p2 = verificar_cota_gamificacion(
            a13=0.2, alpha=1.5, T=5, n_simulaciones=5000, semilla=123
        )
        assert p1 == p2


# ============================================================
# Tests: calcular_similitud_biopython
# ============================================================
class TestSimilitudBiopython:

    def test_matriz_simetrica(self):
        X = np.array([[1.0, 2.0, 3.0], [4.0, 1.0, 6.0], [7.0, 8.0, 2.0]])
        S = calcular_similitud_biopython(X)
        np.testing.assert_array_almost_equal(S, S.T)

    def test_diagonal_uno(self):
        X = np.array([[1.0, 2.0, 3.0], [4.0, 1.0, 6.0], [7.0, 8.0, 2.0]])
        S = calcular_similitud_biopython(X)
        np.testing.assert_array_almost_equal(np.diag(S), np.ones(3))

    def test_rango_cero_uno(self):
        rng = np.random.default_rng(42)
        X = rng.normal(size=(5, 4))
        S = calcular_similitud_biopython(X)
        assert np.all(S >= -1e-10) and np.all(S <= 1 + 1e-10)

    def test_vectores_identicos(self):
        X = np.array([[1.0, 2.0, 3.0], [1.0, 2.0, 3.0]])
        S = calcular_similitud_biopython(X)
        assert abs(S[0, 1] - 1.0) < 1e-10

    def test_vector_constante(self):
        X = np.array([[5.0, 5.0, 5.0], [1.0, 2.0, 3.0]])
        S = calcular_similitud_biopython(X)
        assert abs(S[0, 0] - 1.0) < 1e-10
        assert abs(S[1, 1] - 1.0) < 1e-10
        assert abs(S[0, 1] - 0.0) < 1e-10

    def test_entrada_no_2d(self):
        with pytest.raises(ValueError, match="2D"):
            calcular_similitud_biopython(np.array([1.0, 2.0, 3.0]))


# ============================================================
# Tests: solver de control óptimo (Teorema 5.2)
# ============================================================
class TestControlOptimo:

    def test_resolver_control_optimo_reduce_E(self, modelo_hmm_falso):
        """El solver debe reducir o mantener E_3[T_3] respecto a I_0."""
        I_opt, info = resolver_control_optimo(
            modelo_hmm_falso, epsilon=0.5, verbose=False
        )
        assert info["E_opt"] <= info["E_base"] + 1e-4, (
            f"E_opt = {info['E_opt']:.4f} > E_base = {info['E_base']:.4f}"
        )

    def test_I_opt_es_estocastica(self, modelo_hmm_falso):
        I_opt, _ = resolver_control_optimo(
            modelo_hmm_falso, epsilon=0.5, verbose=False
        )
        verificar_estocasticidad(I_opt, "I_opt")

    def test_I_opt_satisface_restriccion_epsilon(self, modelo_hmm_falso):
        epsilon = 0.3
        I_opt, info = resolver_control_optimo(
            modelo_hmm_falso, epsilon=epsilon, verbose=False
        )
        norma = info["norma_I_menos_I0"]
        assert norma <= epsilon + 1e-4, (
            f"||I_opt - I_0||_1 = {norma:.4f} > ε = {epsilon}"
        )

    def test_resolver_control_optimo_epsilon_cero(self, modelo_hmm_falso):
        """Con ε → 0, la única intervención admisible es I = I_0."""
        I_opt, info = resolver_control_optimo(
            modelo_hmm_falso, epsilon=1e-6, verbose=False
        )
        np.testing.assert_array_almost_equal(I_opt, np.eye(3), decimal=3)

    def test_simular_con_intervencion_optima(self, modelo_hmm_falso):
        I_opt, _ = resolver_control_optimo(
            modelo_hmm_falso, epsilon=0.5, verbose=False
        )
        r = simular_con_intervencion_optima(
            modelo_hmm_falso, I_opt, n_estudiantes=1000,
            n_semanas=10, semilla=42
        )
        assert "p_verificador" in r
        assert 0.0 <= r["p_verificador"] <= 1.0

    def test_simular_con_intervencion_optima_reproducible(self,
                                                            modelo_hmm_falso):
        I_opt, _ = resolver_control_optimo(
            modelo_hmm_falso, epsilon=0.5, verbose=False
        )
        r1 = simular_con_intervencion_optima(
            modelo_hmm_falso, I_opt, n_estudiantes=5000,
            n_semanas=10, semilla=123
        )
        r2 = simular_con_intervencion_optima(
            modelo_hmm_falso, I_opt, n_estudiantes=5000,
            n_semanas=10, semilla=123
        )
        assert r1["p_verificador"] == r2["p_verificador"]


# ============================================================
# Tests de integración
# ============================================================
@pytest.mark.skipif(not HMMLEARN_DISPONIBLE,
                    reason="hmmlearn no instalado")
class TestIntegracion:

    def test_pipeline_completo_sin_archivos(self, df_sintetico_10x10):
        from alfabetizacion import ajustar_hmm, inferir_estados
        df = discretizar_observaciones(df_sintetico_10x10)
        modelo, secuencias, lengths, info = ajustar_hmm(
            df, n_estados=3, n_init=2, n_iter=50
        )
        assert modelo.transmat_.shape == (3, 3)
        assert modelo.emissionprob_.shape == (3, 3)
        assert len(secuencias) == 10
        assert sum(lengths) == 100
        estados = inferir_estados(modelo, secuencias, lengths)
        assert len(estados) == 10

    def test_teorema_4_1_consistente_con_monte_carlo(self,
                                                       matriz_A_ejemplo_7_1):
        """E_3[T_3] = 41/19 ≈ 2.1579; Monte Carlo ±5%."""
        E_teo, _ = calcular_tiempo_retorno(matriz_A_ejemplo_7_1,
                                             estado_objetivo=2)
        A = matriz_A_ejemplo_7_1
        rng = np.random.default_rng(42)
        tiempos = []
        for _ in range(50_000):
            estado = 2
            estado = rng.choice(3, p=A[estado])
            t = 1
            while estado != 2 and t < 1000:
                estado = rng.choice(3, p=A[estado])
                t += 1
            tiempos.append(t)
        E_emp = np.mean(tiempos)
        assert abs(E_emp - E_teo) / E_teo < 0.05

    def test_control_optimo_con_hmm_real(self, df_sintetico_10x10):
        """El OCP funciona con un HMM ajustado de verdad."""
        from alfabetizacion import ajustar_hmm
        df = discretizar_observaciones(df_sintetico_10x10)
        modelo, _, _, _ = ajustar_hmm(df, n_estados=3, n_init=2, n_iter=50)
        I_opt, info = resolver_control_optimo(
            modelo, epsilon=0.5, verbose=False
        )
        assert I_opt.shape == (3, 3)
        verificar_estocasticidad(I_opt, "I_opt con HMM real")
        assert info["E_opt"] <= info["E_base"] + 1e-4


# ============================================================
# Tests de manejo de errores
# ============================================================
class TestManejoErrores:

    def test_archivo_no_existe(self):
        from alfabetizacion import leer_datos
        with pytest.raises(FileNotFoundError):
            leer_datos("archivo_que_no_existe.csv")

    def test_columnas_faltantes(self, tmp_path):
        from alfabetizacion import leer_datos
        ruta = tmp_path / "mal.csv"
        pd.DataFrame({"a": [1, 2], "b": [3, 4]}).to_csv(ruta, index=False)
        with pytest.raises(ValueError, match="Faltan columnas"):
            leer_datos(str(ruta))

    def test_aciertos_fuera_de_rango(self, tmp_path):
        from alfabetizacion import leer_datos
        ruta = tmp_path / "mal2.csv"
        pd.DataFrame({
            "estudiante_id": ["E1"], "semana": [1],
            "aciertos": [15], "tiempo_decision": [5.0], "compartida": [0]
        }).to_csv(ruta, index=False)
        with pytest.raises(ValueError, match="aciertos"):
            leer_datos(str(ruta))

    def test_duplicados(self, tmp_path):
        from alfabetizacion import leer_datos
        ruta = tmp_path / "dup.csv"
        pd.DataFrame({
            "estudiante_id": ["E1", "E1"], "semana": [1, 1],
            "aciertos": [5, 6], "tiempo_decision": [5.0, 6.0],
            "compartida": [0, 1]
        }).to_csv(ruta, index=False)
        with pytest.raises(ValueError, match="duplicadas"):
            leer_datos(str(ruta))
